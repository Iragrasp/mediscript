import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useVoiceRecognition } from "@/hooks/use-voice-recognition";
import { Mic, MicOff, Volume2, Edit, Wand2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface VoiceRecorderProps {
  onTranscriptionComplete: (transcription: string, confidence: number) => void;
  onParseWithAI: (transcription: string) => void;
  language?: string;
  className?: string;
}

export default function VoiceRecorder({
  onTranscriptionComplete,
  onParseWithAI,
  language = "en-US",
  className
}: VoiceRecorderProps) {
  const [editMode, setEditMode] = useState(false);
  const [editedTranscription, setEditedTranscription] = useState("");
  const [volumeLevel, setVolumeLevel] = useState(0);

  const {
    isRecording,
    transcription,
    confidence,
    error,
    isSupported,
    startRecording,
    stopRecording,
    clearTranscription,
  } = useVoiceRecognition({
    language,
    continuous: true,
    interimResults: true,
  });

  // Simulate volume level animation during recording
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setVolumeLevel(Math.random() * 100);
      }, 100);
    } else {
      setVolumeLevel(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  useEffect(() => {
    setEditedTranscription(transcription);
  }, [transcription]);

  useEffect(() => {
    if (transcription && !isRecording) {
      onTranscriptionComplete(transcription, confidence);
    }
  }, [transcription, isRecording, confidence, onTranscriptionComplete]);

  const handleToggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      clearTranscription();
      startRecording();
    }
  };

  const handleEdit = () => {
    setEditMode(true);
  };

  const handleSaveEdit = () => {
    setEditMode(false);
    onTranscriptionComplete(editedTranscription, confidence);
  };

  const handleParseWithAI = () => {
    const textToParse = editMode ? editedTranscription : transcription;
    if (textToParse.trim()) {
      onParseWithAI(textToParse);
    }
  };

  if (!isSupported) {
    return (
      <Card className={className}>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            <Mic className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Speech recognition is not supported in this browser.</p>
            <p className="text-sm mt-2">Please use Chrome, Edge, or Safari for voice input.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardContent className="pt-6">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4 text-foreground">
            Voice-to-Text Prescription Input
          </h2>
          <p className="text-muted-foreground mb-6">
            Speak naturally about the patient and prescription details. Our AI will parse and structure the information.
          </p>

          {/* Voice Control Interface */}
          <div className="flex flex-col items-center space-y-4">
            <Button
              size="lg"
              variant={isRecording ? "destructive" : "default"}
              className={cn(
                "w-24 h-24 rounded-full text-2xl transition-all duration-300",
                isRecording && "animate-pulse"
              )}
              onClick={handleToggleRecording}
              data-testid="record-button"
            >
              {isRecording ? <MicOff /> : <Mic />}
            </Button>

            <div className="text-sm text-muted-foreground">
              <span data-testid="record-status">
                {isRecording ? "Recording... Click to stop" : "Click to start recording"}
              </span>
            </div>

            {/* Volume Indicator */}
            <div className="w-full max-w-md">
              <Progress value={volumeLevel} className="h-2" />
            </div>

            {error && (
              <div className="text-sm text-destructive bg-destructive/10 px-3 py-2 rounded-md">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Transcription Display */}
        <div className="mt-6">
          <label className="block text-sm font-medium text-foreground mb-2">
            Live Transcription
          </label>
          
          {editMode ? (
            <Textarea
              value={editedTranscription}
              onChange={(e) => setEditedTranscription(e.target.value)}
              className="w-full h-32 resize-none"
              placeholder="Edit transcribed text..."
              data-testid="transcription-editor"
            />
          ) : (
            <Textarea
              value={transcription}
              className="w-full h-32 resize-none"
              placeholder="Transcribed text will appear here as you speak..."
              readOnly
              data-testid="transcription-display"
            />
          )}

          <div className="mt-2 flex justify-between items-center">
            <div className="text-sm text-muted-foreground">
              <span data-testid="confidence-score">
                {confidence > 0 ? `Confidence: ${confidence}%` : "Confidence: --"}
              </span>
            </div>
            <div className="space-x-2">
              {editMode ? (
                <Button
                  size="sm"
                  onClick={handleSaveEdit}
                  data-testid="save-edit-button"
                >
                  Save
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={handleEdit}
                  disabled={!transcription}
                  data-testid="edit-transcription-button"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              )}
              
              <Button
                size="sm"
                className="bg-accent hover:bg-accent/90"
                onClick={handleParseWithAI}
                disabled={!transcription && !editedTranscription}
                data-testid="parse-ai-button"
              >
                <Wand2 className="h-4 w-4 mr-1" />
                Parse with AI
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
