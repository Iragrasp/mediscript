import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { generatePrescriptionPDF, downloadPDF } from "@/lib/pdf-generator";
import { useToast } from "@/hooks/use-toast";
import { Eye, Download, Printer, Share, MessageCircle } from "lucide-react";
import type { ClinicSettings } from "@shared/schema";

interface PrescriptionPreviewProps {
  prescription: any;
}

export default function PrescriptionPreview({ prescription }: PrescriptionPreviewProps) {
  const { toast } = useToast();
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const { data: clinicSettings } = useQuery<ClinicSettings>({
    queryKey: ["/api/clinic-settings"],
  });

  const handleGeneratePDF = async () => {
    try {
      setIsGeneratingPDF(true);
      
      // Create a mock prescription object with required fields
      const prescriptionData = {
        ...prescription,
        id: "temp-id",
        prescriptionId: "RX-2024-001",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      const pdfBlob = generatePrescriptionPDF(prescriptionData, clinicSettings || null);
      const filename = `prescription-${prescriptionData.prescriptionId}.pdf`;
      downloadPDF(pdfBlob, filename);
      
      toast({
        title: "PDF Generated",
        description: "Prescription PDF has been downloaded successfully.",
      });
    } catch (error) {
      console.error("PDF generation failed:", error);
      toast({
        title: "PDF Generation Failed",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const message = encodeURIComponent(
      `Prescription for ${prescription.patientName}\nPrescription ID: RX-2024-001\nDate: ${new Date().toLocaleDateString()}\n\nGenerated via MedScript Pro`
    );
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Prescription for ${prescription.patientName}`,
          text: `Prescription ID: RX-2024-001`,
          url: window.location.href,
        });
      } catch (error) {
        console.error("Sharing failed:", error);
      }
    } else {
      toast({
        title: "Share",
        description: "Web Share API not supported. Use WhatsApp or download PDF to share.",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-primary" />
            <span>Prescription Preview</span>
          </CardTitle>
          <div className="space-x-2">
            <Button size="sm" variant="secondary" data-testid="edit-prescription">
              Edit
            </Button>
            <Button
              size="sm"
              onClick={handleGeneratePDF}
              disabled={isGeneratingPDF}
              data-testid="generate-pdf"
            >
              <Download className="h-4 w-4 mr-1" />
              {isGeneratingPDF ? "Generating..." : "PDF"}
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="prescription-preview p-6 rounded-md bg-white text-black">
          {/* Header */}
          {clinicSettings && !clinicSettings.useLetterhead && (
            <>
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gray-800">
                  {clinicSettings.doctorName}
                </h1>
                <p className="text-gray-600">{clinicSettings.specialization}</p>
                <p className="text-sm text-gray-500">
                  Registration No: {clinicSettings.registrationNumber} | Phone: {clinicSettings.phone}
                </p>
                <p className="text-sm text-gray-500">{clinicSettings.address}</p>
              </div>
              <Separator className="my-4" />
            </>
          )}

          {/* Patient Details */}
          <div className="mb-6">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Patient:</strong> {prescription.patientName || "Not specified"}<br />
                <strong>Age:</strong> {prescription.patientAge || "Not specified"} years<br />
                <strong>Gender:</strong> {prescription.patientGender || "Not specified"}
              </div>
              <div className="text-right">
                <strong>Date:</strong> {new Date().toLocaleDateString()}<br />
                <strong>Prescription ID:</strong> RX-2024-001
              </div>
            </div>
          </div>

          {/* Chief Complaints */}
          {prescription.presentComplaints && (
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Chief Complaints:</h3>
              <p className="text-sm">{prescription.presentComplaints}</p>
            </div>
          )}

          {/* Examination Findings */}
          {prescription.examination && Object.keys(prescription.examination).length > 0 && (
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Examination:</h3>
              <div className="text-sm space-y-1">
                {prescription.examination.pulse && (
                  <p>• Pulse: {prescription.examination.pulse} bpm</p>
                )}
                {prescription.examination.bp && (
                  <p>• BP: {prescription.examination.bp}</p>
                )}
                {prescription.examination.temperature && (
                  <p>• Temperature: {prescription.examination.temperature}°F</p>
                )}
                {prescription.examination.spo2 && (
                  <p>• SpO2: {prescription.examination.spo2}%</p>
                )}
                {prescription.examination.additional && (
                  <p>• {prescription.examination.additional}</p>
                )}
              </div>
            </div>
          )}

          {/* Prescription */}
          {prescription.medications && prescription.medications.length > 0 && (
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Rx:</h3>
              <div className="space-y-2 text-sm">
                {prescription.medications
                  .filter((med: any) => med.name)
                  .map((med: any, index: number) => (
                    <div key={index} className="border-l-2 border-gray-300 pl-3">
                      <p><strong>{index + 1}. {med.name}</strong></p>
                      <p>Sig: {med.dosage} ({med.instructions}) for {med.duration}</p>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Instructions */}
          {prescription.additionalNotes && (
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Instructions:</h3>
              <div className="text-sm">
                <p>{prescription.additionalNotes}</p>
              </div>
            </div>
          )}

          {/* Next Review */}
          {prescription.nextReviewDate && (
            <div className="mb-6">
              <p className="text-sm">
                <strong>Next Review:</strong> {new Date(prescription.nextReviewDate).toLocaleDateString()}
              </p>
            </div>
          )}

          {/* Footer */}
          {(!clinicSettings || !clinicSettings.useLetterhead) && (
            <div className="text-center text-xs text-gray-500 border-t pt-4">
              <p>This prescription is computer generated and does not require signature</p>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          <Button
            onClick={handleGeneratePDF}
            disabled={isGeneratingPDF}
            className="flex items-center justify-center"
            data-testid="download-pdf"
          >
            <Download className="h-4 w-4 mr-2" />
            Generate PDF
          </Button>
          
          <Button
            onClick={handleWhatsAppShare}
            className="flex items-center justify-center bg-green-600 hover:bg-green-700"
            data-testid="share-whatsapp"
          >
            <MessageCircle className="h-4 w-4 mr-2" />
            Share via WhatsApp
          </Button>
          
          <Button
            variant="secondary"
            onClick={handlePrint}
            className="flex items-center justify-center"
            data-testid="print-prescription"
          >
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          
          <Button
            variant="outline"
            onClick={handleShare}
            className="flex items-center justify-center"
            data-testid="share-prescription"
          >
            <Share className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
