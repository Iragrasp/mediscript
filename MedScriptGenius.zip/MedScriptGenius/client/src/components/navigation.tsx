import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/voice", label: "Voice Input", icon: "fas fa-microphone" },
  { path: "/prescription", label: "Prescription", icon: "fas fa-prescription" },
  { path: "/history", label: "History", icon: "fas fa-history" },
  { path: "/settings", label: "Settings", icon: "fas fa-cog" },
];

export default function Navigation() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === "/voice" && (location === "/" || location === "/voice")) {
      return true;
    }
    return location === path || location.startsWith(path + "/");
  };

  return (
    <header className="bg-primary text-primary-foreground shadow-md no-print">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-3" data-testid="logo-link">
          <i className="fas fa-stethoscope text-2xl"></i>
          <h1 className="text-xl font-bold">MedScript Pro</h1>
        </Link>
        
        <nav className="hidden md:flex space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={cn(
                "flex items-center space-x-2 hover:text-accent transition-colors",
                isActive(item.path) && "text-accent"
              )}
              data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <i className={item.icon}></i>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <Button
          variant="ghost"
          size="sm"
          className="md:hidden text-primary-foreground hover:text-accent"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="mobile-menu-toggle"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-primary border-t border-primary-foreground/20">
          <div className="container mx-auto px-4 py-2 space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={cn(
                  "flex items-center space-x-2 py-2 hover:text-accent transition-colors",
                  isActive(item.path) && "text-accent"
                )}
                onClick={() => setMobileMenuOpen(false)}
                data-testid={`mobile-nav-${item.label.toLowerCase().replace(" ", "-")}`}
              >
                <i className={item.icon}></i>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
