import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import VoiceRecorder from "@/components/voice-recorder";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, History, File } from "lucide-react";
import type { AIParsedMedicalData } from "@shared/schema";

export default function VoiceInputPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  const parseTranscriptionMutation = useMutation({
    mutationFn: async (transcription: string): Promise<AIParsedMedicalData> => {
      const response = await apiRequest("POST", "/api/ai/parse-transcription", {
        transcription
      });
      return response.json();
    },
    onSuccess: (parsedData) => {
      setIsProcessing(false);
      // Store parsed data in session storage for use in prescription form
      sessionStorage.setItem('aiParsedData', JSON.stringify(parsedData));
      // Navigate to prescription form
      setLocation('/prescription');
      toast({
        title: "AI Parsing Complete",
        description: "Voice input has been successfully parsed and structured.",
      });
    },
    onError: (error) => {
      setIsProcessing(false);
      console.error("AI parsing failed:", error);
      toast({
        title: "AI Parsing Failed",
        description: "Failed to parse transcription. Please try again or edit manually.",
        variant: "destructive",
      });
    },
  });

  const handleTranscriptionComplete = (transcription: string, confidence: number) => {
    console.log("Transcription complete:", { transcription, confidence });
  };

  const handleParseWithAI = async (transcription: string) => {
    setIsProcessing(true);
    setProcessingProgress(0);

    // Simulate progress
    const progressInterval = setInterval(() => {
      setProcessingProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      await parseTranscriptionMutation.mutateAsync(transcription);
      setProcessingProgress(100);
    } catch (error) {
      clearInterval(progressInterval);
      setProcessingProgress(0);
    }
  };

  const handleNewPatient = () => {
    sessionStorage.removeItem('aiParsedData');
    setLocation('/prescription');
  };

  const handleRecentPatient = () => {
    setLocation('/history');
  };

  const handleUseTemplate = () => {
    toast({
      title: "Feature Coming Soon",
      description: "Prescription templates will be available in a future update.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Voice Recording Section */}
      <VoiceRecorder
        onTranscriptionComplete={handleTranscriptionComplete}
        onParseWithAI={handleParseWithAI}
        language="en-US"
      />

      {/* AI Processing Status */}
      {isProcessing && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
              <span className="text-foreground">Processing with Google Gemini AI...</span>
            </div>
            <Progress value={processingProgress} className="w-full" />
            <p className="text-sm text-muted-foreground mt-2">
              Analyzing medical terminology and structuring data...
            </p>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="hover:bg-muted/50 transition-colors cursor-pointer" onClick={handleNewPatient}>
          <CardContent className="pt-6" data-testid="new-patient-card">
            <Plus className="text-primary text-xl mb-2" />
            <h3 className="font-medium text-foreground">New Patient</h3>
            <p className="text-sm text-muted-foreground">Start fresh prescription</p>
          </CardContent>
        </Card>

        <Card className="hover:bg-muted/50 transition-colors cursor-pointer" onClick={handleRecentPatient}>
          <CardContent className="pt-6" data-testid="recent-patient-card">
            <History className="text-primary text-xl mb-2" />
            <h3 className="font-medium text-foreground">Recent Patient</h3>
            <p className="text-sm text-muted-foreground">Continue from history</p>
          </CardContent>
        </Card>

        <Card className="hover:bg-muted/50 transition-colors cursor-pointer" onClick={handleUseTemplate}>
          <CardContent className="pt-6" data-testid="template-card">
            <File className="text-primary text-xl mb-2" />
            <h3 className="font-medium text-foreground">Use Template</h3>
            <p className="text-sm text-muted-foreground">Common prescriptions</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
