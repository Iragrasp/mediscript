import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, History, Eye, RefreshCw, Calendar } from "lucide-react";
import type { Prescription } from "@shared/schema";

export default function HistoryPage() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("30");

  const { data: prescriptions = [], isLoading } = useQuery<Prescription[]>({
    queryKey: ["/api/prescriptions"],
  });

  const { data: searchResults = [] } = useQuery<Prescription[]>({
    queryKey: ["/api/prescriptions/search", searchQuery],
    enabled: searchQuery.length > 0,
  });

  const displayPrescriptions = searchQuery ? searchResults : prescriptions;

  const handleViewPrescription = (id: string) => {
    setLocation(`/prescription/${id}`);
  };

  const handleReusePrescription = (prescription: Prescription) => {
    // Store prescription data for reuse
    sessionStorage.setItem('reusePresetData', JSON.stringify(prescription));
    setLocation('/prescription');
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case 'draft':
        return <Badge variant="secondary">Draft</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <History className="h-5 w-5 text-primary" />
              <span>Prescription History</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-24 bg-muted rounded-lg"></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <History className="h-5 w-5 text-primary" />
            <span>Prescription History</span>
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search by patient name or prescription ID"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-prescriptions"
              />
            </div>
            <div className="flex gap-2">
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-[150px]" data-testid="filter-period">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 3 months</SelectItem>
                  <SelectItem value="180">Last 6 months</SelectItem>
                  <SelectItem value="365">Last year</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" variant="outline" data-testid="search-button">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* History List */}
          {displayPrescriptions.length === 0 ? (
            <div className="text-center py-12">
              <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No Prescriptions Found</h3>
              <p className="text-muted-foreground">
                {searchQuery ? "Try adjusting your search criteria." : "Start by creating your first prescription."}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {displayPrescriptions.map((prescription) => (
                <Card key={prescription.id} className="hover:bg-muted/50 transition-colors">
                  <CardContent className="pt-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-medium text-foreground">
                          {prescription.patientName} ({prescription.patientAge}, {prescription.patientGender})
                        </h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                          <span>{prescription.prescriptionId}</span>
                          <span className="flex items-center">
                            <Calendar className="h-3 w-3 mr-1" />
                            {formatDate(typeof prescription.createdAt === 'string' ? prescription.createdAt : new Date().toISOString())}
                          </span>
                          {getStatusBadge(prescription.status || 'draft')}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => handleViewPrescription(prescription.id)}
                          data-testid={`view-prescription-${prescription.id}`}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleReusePrescription(prescription)}
                          data-testid={`reuse-prescription-${prescription.id}`}
                        >
                          <RefreshCw className="h-4 w-4 mr-1" />
                          Reuse
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-sm text-muted-foreground space-y-1">
                      {prescription.presentComplaints && (
                        <p><strong>Chief Complaint:</strong> {prescription.presentComplaints}</p>
                      )}
                      {prescription.medications && prescription.medications.length > 0 && (
                        <p>
                          <strong>Medications:</strong> {prescription.medications
                            .filter(med => med.name)
                            .map(med => med.name)
                            .join(', ')
                          }
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Pagination */}
          {displayPrescriptions.length > 0 && (
            <div className="flex justify-between items-center mt-6">
              <div className="text-sm text-muted-foreground">
                Showing {displayPrescriptions.length} prescription{displayPrescriptions.length !== 1 ? 's' : ''}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
                  1
                </Button>
                <Button variant="outline" size="sm" disabled>
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
