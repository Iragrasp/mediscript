import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClinicSettingsSchema, type ClinicSettings } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Hospital, Settings, Mic, Smartphone, Save, ChevronUp, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface CollapsibleSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultExpanded?: boolean;
}

function CollapsibleSection({ title, icon, children, defaultExpanded = true }: CollapsibleSectionProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            {icon}
            <span>{title}</span>
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-muted-foreground hover:text-foreground"
          >
            {isExpanded ? <ChevronUp /> : <ChevronDown />}
          </Button>
        </div>
      </CardHeader>
      {isExpanded && <CardContent className="pt-0">{children}</CardContent>}
    </Card>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [speechSensitivity, setSpeechSensitivity] = useState([7]);

  const { data: clinicSettings, isLoading } = useQuery<ClinicSettings>({
    queryKey: ["/api/clinic-settings"],
  });

  const form = useForm({
    resolver: zodResolver(insertClinicSettingsSchema),
    defaultValues: {
      doctorName: "",
      specialization: "",
      registrationNumber: "",
      clinicName: "",
      address: "",
      phone: "",
      email: "",
      includeHeader: true,
      includeFooter: true,
      useLetterhead: false,
      fontSize: "medium",
      prescriptionIdFormat: "RX-YYYY-NNN",
      autoSaveInterval: 60,
      language: "en-US",
      aiModel: "gemini-2.5-flash",
      theme: "light",
    },
  });

  // Load existing settings
  useEffect(() => {
    if (clinicSettings) {
      form.reset({
        ...clinicSettings,
        includeHeader: clinicSettings.includeHeader ?? true,
        includeFooter: clinicSettings.includeFooter ?? true,
        useLetterhead: clinicSettings.useLetterhead ?? false,
        fontSize: clinicSettings.fontSize || "medium",
        prescriptionIdFormat: clinicSettings.prescriptionIdFormat || "RX-YYYY-NNN",
        autoSaveInterval: clinicSettings.autoSaveInterval ?? 60,
        language: clinicSettings.language || "en-US",
        aiModel: clinicSettings.aiModel || "gemini-2.5-flash",
        theme: clinicSettings.theme || "light",
      });
    }
  }, [clinicSettings, form]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/clinic-settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clinic-settings"] });
      toast({
        title: "Settings Saved",
        description: "Your clinic settings have been saved successfully.",
      });
    },
    onError: (error) => {
      console.error("Save settings failed:", error);
      toast({
        title: "Save Failed",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    saveSettingsMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="pt-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded w-1/4"></div>
                  <div className="h-10 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                  <div className="h-10 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Clinic Information */}
          <CollapsibleSection
            title="Clinic Information"
            icon={<Hospital className="h-5 w-5 text-primary" />}
          >
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="doctorName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Doctor Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Dr. Sarah Johnson" 
                        {...field} 
                        data-testid="doctor-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="specialization"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Specialization</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Internal Medicine Specialist" 
                        {...field} 
                        data-testid="specialization"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="registrationNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Registration Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="MD12345" 
                        {...field} 
                        data-testid="registration-number"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="clinicName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Clinic Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Healthcare Medical Center" 
                        {...field} 
                        data-testid="clinic-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="123 Medical Center Drive, Healthcare City, HC 12345"
                        className="resize-none"
                        {...field}
                        data-testid="clinic-address"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          placeholder="+1-555-0123" 
                          {...field} 
                          data-testid="clinic-phone"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="doctor@clinic.com" 
                          {...field} 
                          data-testid="clinic-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </CollapsibleSection>

          {/* Prescription Settings */}
          <CollapsibleSection
            title="Prescription Settings"
            icon={<Settings className="h-5 w-5 text-primary" />}
          >
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="includeHeader"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="include-header"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-normal">
                      Include clinic header
                    </FormLabel>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="includeFooter"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="include-footer"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-normal">
                      Include clinic footer
                    </FormLabel>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="useLetterhead"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="use-letterhead"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-normal">
                      Use letterhead (disable header/footer)
                    </FormLabel>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="fontSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default font size</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="font-size">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="small">Small (10pt)</SelectItem>
                        <SelectItem value="medium">Medium (12pt)</SelectItem>
                        <SelectItem value="large">Large (14pt)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="prescriptionIdFormat"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prescription ID Format</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="prescription-format">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="RX-YYYY-NNN">RX-YYYY-NNN</SelectItem>
                        <SelectItem value="RX-MMDD-NNN">RX-MMDD-NNN</SelectItem>
                        <SelectItem value="custom">Custom format</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="autoSaveInterval"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Auto-save interval</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(parseInt(value))} 
                      value={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="autosave-interval">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="30">30 seconds</SelectItem>
                        <SelectItem value="60">1 minute</SelectItem>
                        <SelectItem value="300">5 minutes</SelectItem>
                        <SelectItem value="0">Disabled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CollapsibleSection>

          {/* Voice Settings */}
          <CollapsibleSection
            title="Voice Settings"
            icon={<Mic className="h-5 w-5 text-primary" />}
          >
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="language"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Language</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="voice-language">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="en-GB">English (UK)</SelectItem>
                        <SelectItem value="hi-IN">Hindi</SelectItem>
                        <SelectItem value="es-ES">Spanish</SelectItem>
                        <SelectItem value="fr-FR">French</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel>Speech recognition sensitivity</FormLabel>
                <div className="mt-2">
                  <Slider
                    value={speechSensitivity}
                    onValueChange={setSpeechSensitivity}
                    max={10}
                    min={1}
                    step={1}
                    className="w-full"
                    data-testid="speech-sensitivity"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>Low</span>
                    <span>High</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex flex-row items-start space-x-3 space-y-0">
                  <Checkbox defaultChecked data-testid="auto-parse-ai" />
                  <label className="text-sm font-normal">
                    Auto-parse with AI after recording
                  </label>
                </div>

                <div className="flex flex-row items-start space-x-3 space-y-0">
                  <Checkbox defaultChecked data-testid="medical-terminology" />
                  <label className="text-sm font-normal">
                    Medical terminology enhancement
                  </label>
                </div>
              </div>

              <FormField
                control={form.control}
                name="aiModel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>AI Model</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="ai-model">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="gemini-2.5-flash">Google Gemini Flash</SelectItem>
                        <SelectItem value="gemini-2.5-pro">Google Gemini Pro</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CollapsibleSection>

          {/* App Settings */}
          <CollapsibleSection
            title="App Settings"
            icon={<Smartphone className="h-5 w-5 text-primary" />}
          >
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="theme"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Theme</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="app-theme">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="system">Auto (System)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-3">
                <div className="flex flex-row items-start space-x-3 space-y-0">
                  <Checkbox defaultChecked data-testid="auto-backup" />
                  <label className="text-sm font-normal">
                    Auto-backup to cloud
                  </label>
                </div>

                <div className="flex flex-row items-start space-x-3 space-y-0">
                  <Checkbox data-testid="offline-mode" />
                  <label className="text-sm font-normal">
                    Offline mode
                  </label>
                </div>
              </div>

              <div>
                <FormLabel>Data retention</FormLabel>
                <Select defaultValue="2-years">
                  <SelectTrigger className="mt-2" data-testid="data-retention">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-year">1 year</SelectItem>
                    <SelectItem value="2-years">2 years</SelectItem>
                    <SelectItem value="5-years">5 years</SelectItem>
                    <SelectItem value="indefinite">Indefinite</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator className="my-4" />

              <Button
                type="submit"
                className="w-full"
                disabled={saveSettingsMutation.isPending}
                data-testid="save-settings"
              >
                <Save className="h-4 w-4 mr-2" />
                {saveSettingsMutation.isPending ? "Saving..." : "Save Settings"}
              </Button>
            </div>
          </CollapsibleSection>
        </div>
      </form>
    </Form>
  );
}
