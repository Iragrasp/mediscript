import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPrescriptionSchema, type AIParsedMedicalData } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import PrescriptionPreview from "@/components/prescription-preview";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, User, Stethoscope, ClipboardList, Heart, Pill, ChevronUp, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { z } from "zod";

const formSchema = insertPrescriptionSchema.extend({
  medications: z.array(z.object({
    name: z.string().min(1, "Medicine name is required"),
    dosage: z.string().min(1, "Dosage is required"),
    duration: z.string().min(1, "Duration is required"),
    instructions: z.string().min(1, "Instructions are required"),
  })).min(1, "At least one medication is required"),
  examination: z.object({
    pulse: z.number().optional(),
    bp: z.string().optional(),
    temperature: z.number().optional(),
    spo2: z.number().optional(),
    additional: z.string().optional(),
  }).optional(),
  menstrualHistory: z.object({
    lmp: z.string().optional(),
    cycle: z.string().optional(),
    details: z.string().optional(),
  }).optional(),
  comorbidities: z.object({
    htn: z.boolean().optional(),
    dm: z.boolean().optional(),
    hypothyroid: z.boolean().optional(),
    ihd: z.boolean().optional(),
    cva: z.boolean().optional(),
  }).optional(),
});

interface CollapsibleSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultExpanded?: boolean;
}

function CollapsibleSection({ title, icon, children, defaultExpanded = true }: CollapsibleSectionProps) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            {icon}
            <span>{title}</span>
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-muted-foreground hover:text-foreground"
          >
            {isExpanded ? <ChevronUp /> : <ChevronDown />}
          </Button>
        </div>
      </CardHeader>
      {isExpanded && <CardContent className="pt-0">{children}</CardContent>}
    </Card>
  );
}

export default function PrescriptionFormPage() {
  const [match, params] = useRoute("/prescription/:id");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showMenstrual, setShowMenstrual] = useState(false);

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      patientName: "",
      patientAge: 0,
      patientGender: "",
      patientPhone: "",
      patientAddress: "",
      presentComplaints: "",
      pastHistory: "",
      currentMedications: "",
      comorbidities: {
        htn: false,
        dm: false,
        hypothyroid: false,
        ihd: false,
        cva: false,
      },
      examination: {
        pulse: undefined,
        bp: "",
        temperature: undefined,
        spo2: undefined,
        additional: "",
      },
      menstrualHistory: {
        lmp: "",
        cycle: "",
        details: "",
      },
      medications: [{ name: "", dosage: "", duration: "", instructions: "" }],
      nextReviewDate: "",
      additionalNotes: "",
      status: "draft",
    },
  });

  // Load AI parsed data on component mount
  useEffect(() => {
    const aiParsedData = sessionStorage.getItem('aiParsedData');
    if (aiParsedData) {
      try {
        const parsedData: AIParsedMedicalData = JSON.parse(aiParsedData);
        
        // Populate form with AI parsed data
        if (parsedData.patient) {
          if (parsedData.patient.name) form.setValue('patientName', parsedData.patient.name);
          if (parsedData.patient.age) form.setValue('patientAge', parsedData.patient.age);
          if (parsedData.patient.gender) {
            form.setValue('patientGender', parsedData.patient.gender);
            setShowMenstrual(parsedData.patient.gender.toLowerCase() === 'female');
          }
          if (parsedData.patient.phone) form.setValue('patientPhone', parsedData.patient.phone);
          if (parsedData.patient.address) form.setValue('patientAddress', parsedData.patient.address);
        }

        if (parsedData.medical) {
          if (parsedData.medical.complaints) form.setValue('presentComplaints', parsedData.medical.complaints);
          if (parsedData.medical.pastHistory) form.setValue('pastHistory', parsedData.medical.pastHistory);
          if (parsedData.medical.currentMeds) form.setValue('currentMedications', parsedData.medical.currentMeds);
        }

        if (parsedData.comorbidities) {
          form.setValue('comorbidities', {
            htn: parsedData.comorbidities.htn || false,
            dm: parsedData.comorbidities.dm || false,
            hypothyroid: parsedData.comorbidities.hypothyroid || false,
            ihd: parsedData.comorbidities.ihd || false,
            cva: parsedData.comorbidities.cva || false,
          });
        }

        if (parsedData.examination) {
          form.setValue('examination', {
            pulse: parsedData.examination.pulse,
            bp: parsedData.examination.bp || '',
            temperature: parsedData.examination.temperature,
            spo2: parsedData.examination.spo2,
            additional: parsedData.examination.additional || '',
          });
        }

        if (parsedData.menstrual) {
          form.setValue('menstrualHistory', {
            lmp: parsedData.menstrual.lmp || '',
            cycle: parsedData.menstrual.cycle || '',
            details: parsedData.menstrual.details || '',
          });
        }

        if (parsedData.medications && parsedData.medications.length > 0) {
          form.setValue('medications', parsedData.medications);
        }

        if (parsedData.nextReviewDate) {
          form.setValue('nextReviewDate', parsedData.nextReviewDate);
        }

        if (parsedData.notes) {
          form.setValue('additionalNotes', parsedData.notes);
        }

        // Clear the session storage after loading
        sessionStorage.removeItem('aiParsedData');
        
        toast({
          title: "AI Data Loaded",
          description: "Voice input has been automatically filled in the form.",
        });
      } catch (error) {
        console.error("Failed to load AI parsed data:", error);
      }
    }
  }, [form, toast]);

  // Watch gender changes to show/hide menstrual history
  const watchedGender = form.watch("patientGender");
  useEffect(() => {
    setShowMenstrual(watchedGender === "female");
  }, [watchedGender]);

  // Load existing prescription if editing
  const { data: existingPrescription } = useQuery({
    queryKey: ["/api/prescriptions", params?.id],
    enabled: !!params?.id,
  });

  useEffect(() => {
    if (existingPrescription) {
      form.reset(existingPrescription);
    }
  }, [existingPrescription, form]);

  const savePrescriptionMutation = useMutation({
    mutationFn: async (data: any) => {
      if (params?.id) {
        return apiRequest("PATCH", `/api/prescriptions/${params.id}`, data);
      } else {
        return apiRequest("POST", "/api/prescriptions", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prescriptions"] });
      toast({
        title: "Prescription Saved",
        description: "Prescription has been saved successfully.",
      });
    },
    onError: (error) => {
      console.error("Save failed:", error);
      toast({
        title: "Save Failed",
        description: "Failed to save prescription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addMedication = () => {
    const currentMeds = form.getValues("medications");
    form.setValue("medications", [
      ...currentMeds,
      { name: "", dosage: "", duration: "", instructions: "" },
    ]);
  };

  const removeMedication = (index: number) => {
    const currentMeds = form.getValues("medications");
    if (currentMeds.length > 1) {
      form.setValue(
        "medications",
        currentMeds.filter((_, i) => i !== index)
      );
    }
  };

  const onSubmit = (data: any) => {
    savePrescriptionMutation.mutate(data);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Patient Information Form */}
      <div className="space-y-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Patient Demographics */}
            <CollapsibleSection
              title="Patient Information"
              icon={<User className="h-5 w-5 text-primary" />}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="patientName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Patient Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter full name" {...field} data-testid="patient-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="patientAge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age *</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="Years"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          data-testid="patient-age"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="patientGender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gender *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="patient-gender">
                            <SelectValue placeholder="Select gender" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="patientPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Number</FormLabel>
                      <FormControl>
                        <Input type="tel" placeholder="Phone number" {...field} data-testid="patient-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="patientAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Patient address"
                        className="resize-none"
                        {...field}
                        data-testid="patient-address"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CollapsibleSection>

            {/* Medical History */}
            <CollapsibleSection
              title="Medical History"
              icon={<ClipboardList className="h-5 w-5 text-primary" />}
            >
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="presentComplaints"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Present Complaints</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Current symptoms and complaints"
                          className="resize-none"
                          {...field}
                          data-testid="present-complaints"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="pastHistory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Past Medical History</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Previous illnesses, surgeries, hospitalizations"
                          className="resize-none"
                          {...field}
                          data-testid="past-history"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="currentMedications"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Medications</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Current ongoing medications"
                          className="resize-none"
                          {...field}
                          data-testid="current-medications"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Comorbidities</FormLabel>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {[
                      { key: "htn", label: "HTN" },
                      { key: "dm", label: "DM" },
                      { key: "hypothyroid", label: "Hypothyroid" },
                      { key: "ihd", label: "IHD" },
                      { key: "cva", label: "CVA" },
                    ].map((comorbidity) => (
                      <FormField
                        key={comorbidity.key}
                        control={form.control}
                        name={`comorbidities.${comorbidity.key}` as any}
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                data-testid={`comorbidity-${comorbidity.key}`}
                              />
                            </FormControl>
                            <FormLabel className="text-sm font-normal">
                              {comorbidity.label}
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </CollapsibleSection>

            {/* Examination Findings */}
            <CollapsibleSection
              title="Examination"
              icon={<Stethoscope className="h-5 w-5 text-primary" />}
            >
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="examination.pulse"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pulse (bpm)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="72"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          data-testid="examination-pulse"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="examination.bp"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blood Pressure</FormLabel>
                      <FormControl>
                        <Input placeholder="120/80" {...field} data-testid="examination-bp" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="examination.temperature"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Temperature (°F)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.1"
                          placeholder="98.6"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || undefined)}
                          data-testid="examination-temperature"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="examination.spo2"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SpO2 (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="98"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                          data-testid="examination-spo2"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="examination.additional"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Findings</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Spine, knee, other examination findings"
                        className="resize-none"
                        {...field}
                        data-testid="examination-additional"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CollapsibleSection>

            {/* Menstrual History (Female Only) */}
            {showMenstrual && (
              <CollapsibleSection
                title="Menstrual History"
                icon={<Heart className="h-5 w-5 text-primary" />}
                defaultExpanded={false}
              >
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="menstrualHistory.lmp"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>LMP</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} data-testid="menstrual-lmp" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="menstrualHistory.cycle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cycle Length</FormLabel>
                        <FormControl>
                          <Input placeholder="28 days" {...field} data-testid="menstrual-cycle" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="menstrualHistory.details"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Menstrual History Details</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Regularity, flow, associated symptoms"
                          className="resize-none"
                          {...field}
                          data-testid="menstrual-details"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CollapsibleSection>
            )}

            {/* Prescription Details */}
            <CollapsibleSection
              title="Prescription"
              icon={<Pill className="h-5 w-5 text-primary" />}
            >
              <div className="space-y-4">
                <div className="space-y-3">
                  {form.watch("medications").map((_, index) => (
                    <Card key={index} className="border border-border">
                      <CardContent className="pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <FormField
                            control={form.control}
                            name={`medications.${index}.name`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Medicine Name</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="e.g., Paracetamol 500mg"
                                    {...field}
                                    data-testid={`medication-name-${index}`}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`medications.${index}.dosage`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Dosage</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="e.g., 1-0-1"
                                    {...field}
                                    data-testid={`medication-dosage-${index}`}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`medications.${index}.duration`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Duration</FormLabel>
                                <FormControl>
                                  <Input
                                    placeholder="e.g., 7 days"
                                    {...field}
                                    data-testid={`medication-duration-${index}`}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name={`medications.${index}.instructions`}
                          render={({ field }) => (
                            <FormItem className="mt-3">
                              <FormLabel>Instructions</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="e.g., After meals"
                                  {...field}
                                  data-testid={`medication-instructions-${index}`}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="mt-3 flex justify-end">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeMedication(index)}
                            disabled={form.watch("medications").length === 1}
                            className="text-destructive hover:text-destructive/80"
                            data-testid={`remove-medication-${index}`}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-dashed"
                  onClick={addMedication}
                  data-testid="add-medication"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Medicine
                </Button>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="nextReviewDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Next Review Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} data-testid="next-review-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Diet recommendations, lifestyle advice, etc."
                          className="resize-none"
                          {...field}
                          data-testid="additional-notes"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator className="my-4" />

              <Button
                type="submit"
                className="w-full"
                disabled={savePrescriptionMutation.isPending}
                data-testid="save-prescription"
              >
                {savePrescriptionMutation.isPending ? "Saving..." : "Save Prescription"}
              </Button>
            </CollapsibleSection>
          </form>
        </Form>
      </div>

      {/* Prescription Preview */}
      <div className="space-y-6">
        <PrescriptionPreview prescription={form.watch()} />
      </div>
    </div>
  );
}
