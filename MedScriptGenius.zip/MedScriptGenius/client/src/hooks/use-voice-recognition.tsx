import { useState, useCallback, useRef, useEffect } from "react";
import { medicalTerms } from "@/lib/medical-terms";

// Extend Window interface for Speech Recognition types
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    SpeechRecognition: any;
  }
}

interface VoiceRecognitionState {
  isRecording: boolean;
  transcription: string;
  confidence: number;
  error: string | null;
  isSupported: boolean;
}

interface VoiceRecognitionOptions {
  language?: string;
  continuous?: boolean;
  interimResults?: boolean;
  maxAlternatives?: number;
}

export function useVoiceRecognition(options: VoiceRecognitionOptions = {}) {
  const [state, setState] = useState<VoiceRecognitionState>({
    isRecording: false,
    transcription: "",
    confidence: 0,
    error: null,
    isSupported: typeof window !== "undefined" && "webkitSpeechRecognition" in window,
  });

  const recognitionRef = useRef<any>(null);
  const finalTranscriptRef = useRef("");

  const {
    language = "en-US",
    continuous = true,
    interimResults = true,
    maxAlternatives = 1,
  } = options;

  // Enhance transcription with medical terms
  const enhanceTranscription = useCallback((text: string) => {
    let enhanced = text;
    
    // Apply medical term corrections
    medicalTerms.forEach(({ incorrect, correct }) => {
      const regex = new RegExp(`\\b${incorrect}\\b`, 'gi');
      enhanced = enhanced.replace(regex, correct);
    });

    return enhanced;
  }, []);

  useEffect(() => {
    if (!state.isSupported) return;

    const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
    
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      
      const recognition = recognitionRef.current;
      recognition.lang = language;
      recognition.continuous = continuous;
      recognition.interimResults = interimResults;
      recognition.maxAlternatives = maxAlternatives;

      recognition.onstart = () => {
        setState(prev => ({ ...prev, isRecording: true, error: null }));
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = "";
        let finalTranscript = finalTranscriptRef.current;
        let totalConfidence = 0;
        let resultCount = 0;

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const transcript = result[0].transcript;
          
          if (result.isFinal) {
            finalTranscript += transcript;
            totalConfidence += result[0].confidence;
            resultCount++;
          } else {
            interimTranscript += transcript;
          }
        }

        finalTranscriptRef.current = finalTranscript;
        const fullTranscript = enhanceTranscription(finalTranscript + interimTranscript);
        const avgConfidence = resultCount > 0 ? totalConfidence / resultCount : 0;

        setState(prev => ({
          ...prev,
          transcription: fullTranscript,
          confidence: Math.round(avgConfidence * 100),
        }));
      };

      recognition.onerror = (event: any) => {
        setState(prev => ({
          ...prev,
          error: `Speech recognition error: ${event.error}`,
          isRecording: false,
        }));
      };

      recognition.onend = () => {
        setState(prev => ({ ...prev, isRecording: false }));
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [language, continuous, interimResults, maxAlternatives, enhanceTranscription, state.isSupported]);

  const startRecording = useCallback(() => {
    if (!state.isSupported || !recognitionRef.current) {
      setState(prev => ({ ...prev, error: "Speech recognition not supported" }));
      return;
    }

    finalTranscriptRef.current = "";
    setState(prev => ({ ...prev, transcription: "", confidence: 0, error: null }));
    recognitionRef.current.start();
  }, [state.isSupported]);

  const stopRecording = useCallback(() => {
    if (recognitionRef.current && state.isRecording) {
      recognitionRef.current.stop();
    }
  }, [state.isRecording]);

  const clearTranscription = useCallback(() => {
    finalTranscriptRef.current = "";
    setState(prev => ({ ...prev, transcription: "", confidence: 0 }));
  }, []);

  return {
    ...state,
    startRecording,
    stopRecording,
    clearTranscription,
  };
}
