// Medical terminology corrections for voice recognition
export const medicalTerms = [
  // Common medical conditions
  { incorrect: "high blood pressure", correct: "hypertension" },
  { incorrect: "htn", correct: "hypertension" },
  { incorrect: "diabetes mellitus", correct: "diabetes" },
  { incorrect: "dm", correct: "diabetes" },
  { incorrect: "thyroid", correct: "hypothyroid" },
  { incorrect: "heart disease", correct: "IHD" },
  { incorrect: "stroke", correct: "CVA" },
  
  // Vital signs
  { incorrect: "blood pressure", correct: "BP" },
  { incorrect: "beats per minute", correct: "bpm" },
  { incorrect: "oxygen saturation", correct: "SpO2" },
  { incorrect: "temperature", correct: "temp" },
  
  // Common medications
  { incorrect: "paracetamol", correct: "Paracetamol" },
  { incorrect: "ibuprofen", correct: "Ibuprofen" },
  { incorrect: "aspirin", correct: "Aspirin" },
  { incorrect: "metformin", correct: "Metformin" },
  { incorrect: "amlodipine", correct: "Amlodipine" },
  { incorrect: "atorvastatin", correct: "Atorvastatin" },
  { incorrect: "lisinopril", correct: "Lisinopril" },
  { incorrect: "omeprazole", correct: "Omeprazole" },
  
  // Dosage instructions
  { incorrect: "once daily", correct: "1-0-0" },
  { incorrect: "twice daily", correct: "1-0-1" },
  { incorrect: "three times daily", correct: "1-1-1" },
  { incorrect: "four times daily", correct: "1-1-1-1" },
  { incorrect: "before meals", correct: "before food" },
  { incorrect: "after meals", correct: "after food" },
  { incorrect: "as needed", correct: "PRN" },
  { incorrect: "when required", correct: "PRN" },
  
  // Time periods
  { incorrect: "milligrams", correct: "mg" },
  { incorrect: "milligram", correct: "mg" },
  { incorrect: "tablet", correct: "tab" },
  { incorrect: "tablets", correct: "tabs" },
  { incorrect: "capsule", correct: "cap" },
  { incorrect: "capsules", correct: "caps" },
  
  // Medical examination terms
  { incorrect: "heart rate", correct: "pulse" },
  { incorrect: "respiratory rate", correct: "RR" },
  { incorrect: "chest examination", correct: "chest exam" },
  { incorrect: "abdominal examination", correct: "abdominal exam" },
  
  // Common symptoms
  { incorrect: "stomach pain", correct: "abdominal pain" },
  { incorrect: "chest pain", correct: "chest discomfort" },
  { incorrect: "shortness of breath", correct: "dyspnea" },
  { incorrect: "difficulty breathing", correct: "dyspnea" },
  { incorrect: "nausea", correct: "nausea" },
  { incorrect: "vomiting", correct: "vomiting" },
  { incorrect: "diarrhea", correct: "loose stools" },
  { incorrect: "constipation", correct: "constipation" },
  
  // Units and measurements
  { incorrect: "degrees celsius", correct: "°C" },
  { incorrect: "degrees fahrenheit", correct: "°F" },
  { incorrect: "percent", correct: "%" },
  { incorrect: "millimeters of mercury", correct: "mmHg" },
  
  // Medical procedures
  { incorrect: "blood test", correct: "blood investigation" },
  { incorrect: "x-ray", correct: "X-ray" },
  { incorrect: "ct scan", correct: "CT scan" },
  { incorrect: "mri scan", correct: "MRI scan" },
  { incorrect: "ecg", correct: "ECG" },
  { incorrect: "echo", correct: "echocardiogram" },
];

// Medical specialty terms
export const specialtyTerms = [
  "cardiology", "neurology", "gastroenterology", "pulmonology",
  "endocrinology", "rheumatology", "nephrology", "oncology",
  "dermatology", "orthopedics", "psychiatry", "pediatrics",
  "gynecology", "urology", "ophthalmology", "ENT"
];

// Common prescription patterns
export const prescriptionPatterns = [
  // Dosage patterns
  /(\d+)-(\d+)-(\d+)/g, // 1-0-1 format
  /(\d+)\s*mg/gi, // dosage in mg
  /(\d+)\s*days?/gi, // duration in days
  /(\d+)\s*weeks?/gi, // duration in weeks
  /(\d+)\s*months?/gi, // duration in months
];

// Function to validate and format medical text
export function formatMedicalText(text: string): string {
  let formatted = text;
  
  // Apply medical term corrections
  medicalTerms.forEach(({ incorrect, correct }) => {
    const regex = new RegExp(`\\b${incorrect}\\b`, 'gi');
    formatted = formatted.replace(regex, correct);
  });
  
  // Capitalize drug names and medical terms
  specialtyTerms.forEach(term => {
    const regex = new RegExp(`\\b${term}\\b`, 'gi');
    formatted = formatted.replace(regex, term.charAt(0).toUpperCase() + term.slice(1));
  });
  
  return formatted;
}
