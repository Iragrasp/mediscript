import jsPDF from 'jspdf';
import type { Prescription, ClinicSettings } from '@shared/schema';

interface PDFOptions {
  includeHeader?: boolean;
  includeFooter?: boolean;
  fontSize?: 'small' | 'medium' | 'large';
}

const fontSizes = {
  small: { title: 16, heading: 12, body: 10 },
  medium: { title: 18, heading: 14, body: 12 },
  large: { title: 20, heading: 16, body: 14 },
};

export class PrescriptionPDFGenerator {
  private pdf: jsPDF;
  private yPosition: number = 20;
  private pageHeight: number;
  private margin: number = 20;

  constructor() {
    this.pdf = new jsPDF();
    this.pageHeight = this.pdf.internal.pageSize.height;
  }

  generatePrescriptionPDF(
    prescription: Prescription,
    clinicSettings: ClinicSettings | null,
    options: PDFOptions = {}
  ): Blob {
    const {
      includeHeader = true,
      includeFooter = true,
      fontSize = 'medium'
    } = options;

    const fonts = fontSizes[fontSize];

    // Reset position
    this.yPosition = 20;

    // Add header if enabled and clinic settings available
    if (includeHeader && clinicSettings && !clinicSettings.useLetterhead) {
      this.addHeader(clinicSettings, fonts);
    }

    // Add prescription content
    this.addPrescriptionContent(prescription, fonts);

    // Add footer if enabled
    if (includeFooter && !clinicSettings?.useLetterhead) {
      this.addFooter(fonts);
    }

    return this.pdf.output('blob');
  }

  private addHeader(settings: ClinicSettings, fonts: any): void {
    const centerX = this.pdf.internal.pageSize.width / 2;

    // Doctor name and clinic
    this.pdf.setFontSize(fonts.title);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text(settings.doctorName, centerX, this.yPosition, { align: 'center' });
    this.yPosition += 8;

    this.pdf.setFontSize(fonts.heading);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(settings.specialization, centerX, this.yPosition, { align: 'center' });
    this.yPosition += 6;

    // Registration and contact
    this.pdf.setFontSize(fonts.body);
    this.pdf.text(
      `Registration No: ${settings.registrationNumber} | Phone: ${settings.phone}`,
      centerX,
      this.yPosition,
      { align: 'center' }
    );
    this.yPosition += 6;

    // Clinic address
    this.pdf.text(settings.address, centerX, this.yPosition, { align: 'center' });
    this.yPosition += 10;

    // Add separator line
    this.pdf.line(this.margin, this.yPosition, this.pdf.internal.pageSize.width - this.margin, this.yPosition);
    this.yPosition += 15;
  }

  private addPrescriptionContent(prescription: Prescription, fonts: any): void {
    // Patient details section
    this.addPatientDetails(prescription, fonts);
    
    // Chief complaints
    this.addSection('Chief Complaints:', prescription.presentComplaints || 'Not specified', fonts);
    
    // Examination findings if available
    if (prescription.examination) {
      this.addExaminationFindings(prescription.examination, fonts);
    }
    
    // Prescription medications
    this.addMedications(prescription.medications || [], fonts);
    
    // Additional instructions
    if (prescription.additionalNotes) {
      this.addSection('Instructions:', prescription.additionalNotes, fonts);
    }
    
    // Next review date
    if (prescription.nextReviewDate) {
      this.addSection('Next Review:', prescription.nextReviewDate, fonts);
    }
  }

  private addPatientDetails(prescription: Prescription, fonts: any): void {
    const leftCol = this.margin;
    const rightCol = this.pdf.internal.pageSize.width - this.margin - 80;

    this.pdf.setFontSize(fonts.body);
    this.pdf.setFont('helvetica', 'bold');

    // Left column - Patient details
    this.pdf.text('Patient:', leftCol, this.yPosition);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(prescription.patientName, leftCol + 25, this.yPosition);
    this.yPosition += 6;

    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Age:', leftCol, this.yPosition);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(`${prescription.patientAge} years`, leftCol + 25, this.yPosition);
    this.yPosition += 6;

    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Gender:', leftCol, this.yPosition);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(prescription.patientGender, leftCol + 25, this.yPosition);

    // Right column - Date and ID
    this.yPosition -= 12;
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Date:', rightCol, this.yPosition);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(new Date(prescription.createdAt || Date.now()).toLocaleDateString(), rightCol + 20, this.yPosition);
    this.yPosition += 6;

    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Prescription ID:', rightCol, this.yPosition);
    this.pdf.setFont('helvetica', 'normal');
    this.pdf.text(prescription.prescriptionId, rightCol + 45, this.yPosition);

    this.yPosition += 15;
  }

  private addExaminationFindings(examination: any, fonts: any): void {
    this.pdf.setFontSize(fonts.heading);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Examination:', this.margin, this.yPosition);
    this.yPosition += 8;

    this.pdf.setFontSize(fonts.body);
    this.pdf.setFont('helvetica', 'normal');

    const findings = [];
    if (examination.pulse) findings.push(`Pulse: ${examination.pulse} bpm`);
    if (examination.bp) findings.push(`BP: ${examination.bp}`);
    if (examination.temperature) findings.push(`Temperature: ${examination.temperature}°F`);
    if (examination.spo2) findings.push(`SpO2: ${examination.spo2}%`);

    findings.forEach(finding => {
      this.pdf.text(`• ${finding}`, this.margin + 5, this.yPosition);
      this.yPosition += 5;
    });

    if (examination.additional) {
      this.pdf.text(`• ${examination.additional}`, this.margin + 5, this.yPosition);
      this.yPosition += 5;
    }

    this.yPosition += 5;
  }

  private addMedications(medications: any[], fonts: any): void {
    this.pdf.setFontSize(fonts.heading);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text('Rx:', this.margin, this.yPosition);
    this.yPosition += 8;

    this.pdf.setFontSize(fonts.body);
    
    medications.forEach((med, index) => {
      // Check if we need a new page
      if (this.yPosition > this.pageHeight - 40) {
        this.pdf.addPage();
        this.yPosition = 20;
      }

      this.pdf.setFont('helvetica', 'bold');
      this.pdf.text(`${index + 1}. ${med.name}`, this.margin + 5, this.yPosition);
      this.yPosition += 6;

      this.pdf.setFont('helvetica', 'normal');
      this.pdf.text(`    Sig: ${med.dosage} (${med.instructions}) for ${med.duration}`, this.margin + 5, this.yPosition);
      this.yPosition += 8;
    });

    this.yPosition += 5;
  }

  private addSection(title: string, content: string, fonts: any): void {
    this.pdf.setFontSize(fonts.heading);
    this.pdf.setFont('helvetica', 'bold');
    this.pdf.text(title, this.margin, this.yPosition);
    this.yPosition += 8;

    this.pdf.setFontSize(fonts.body);
    this.pdf.setFont('helvetica', 'normal');
    
    const lines = this.pdf.splitTextToSize(content, this.pdf.internal.pageSize.width - 2 * this.margin);
    lines.forEach((line: string) => {
      this.pdf.text(line, this.margin + 5, this.yPosition);
      this.yPosition += 5;
    });

    this.yPosition += 5;
  }

  private addFooter(fonts: any): void {
    const centerX = this.pdf.internal.pageSize.width / 2;
    const footerY = this.pageHeight - 20;

    this.pdf.setFontSize(fonts.body - 2);
    this.pdf.setFont('helvetica', 'italic');
    this.pdf.text(
      'This prescription is computer generated and does not require signature',
      centerX,
      footerY,
      { align: 'center' }
    );
  }
}

export function generatePrescriptionPDF(
  prescription: Prescription,
  clinicSettings: ClinicSettings | null,
  options?: PDFOptions
): Blob {
  const generator = new PrescriptionPDFGenerator();
  return generator.generatePrescriptionPDF(prescription, clinicSettings, options);
}

export function downloadPDF(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
