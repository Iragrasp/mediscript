import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const clinicSettings = pgTable("clinic_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  doctorName: text("doctor_name").notNull(),
  specialization: text("specialization").notNull(),
  registrationNumber: text("registration_number").notNull(),
  clinicName: text("clinic_name").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  includeHeader: boolean("include_header").default(true),
  includeFooter: boolean("include_footer").default(true),
  useLetterhead: boolean("use_letterhead").default(false),
  fontSize: text("font_size").default("medium"),
  prescriptionIdFormat: text("prescription_id_format").default("RX-YYYY-NNN"),
  autoSaveInterval: integer("auto_save_interval").default(60),
  language: text("language").default("en-US"),
  aiModel: text("ai_model").default("gemini-2.5-flash"),
  theme: text("theme").default("light"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const patients = pgTable("patients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  gender: text("gender").notNull(),
  phone: text("phone"),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const prescriptions = pgTable("prescriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prescriptionId: text("prescription_id").notNull().unique(),
  patientId: varchar("patient_id").references(() => patients.id),
  patientName: text("patient_name").notNull(),
  patientAge: integer("patient_age").notNull(),
  patientGender: text("patient_gender").notNull(),
  patientPhone: text("patient_phone"),
  patientAddress: text("patient_address"),
  
  // Medical History
  presentComplaints: text("present_complaints"),
  pastHistory: text("past_history"),
  currentMedications: text("current_medications"),
  comorbidities: jsonb("comorbidities").$type<{
    htn?: boolean;
    dm?: boolean;
    hypothyroid?: boolean;
    ihd?: boolean;
    cva?: boolean;
  }>(),
  
  // Examination
  examination: jsonb("examination").$type<{
    pulse?: number;
    bp?: string;
    temperature?: number;
    spo2?: number;
    additional?: string;
  }>(),
  
  // Menstrual History (for females)
  menstrualHistory: jsonb("menstrual_history").$type<{
    lmp?: string;
    cycle?: string;
    details?: string;
  }>(),
  
  // Prescription Details
  medications: jsonb("medications").$type<Array<{
    name: string;
    dosage: string;
    duration: string;
    instructions: string;
  }>>(),
  
  nextReviewDate: text("next_review_date"),
  additionalNotes: text("additional_notes"),
  
  // Voice Input Data
  voiceTranscription: text("voice_transcription"),
  aiParsedData: jsonb("ai_parsed_data"),
  confidenceScore: integer("confidence_score"),
  
  status: text("status").default("draft"), // draft, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const voiceRecordings = pgTable("voice_recordings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prescriptionId: varchar("prescription_id").references(() => prescriptions.id),
  transcription: text("transcription").notNull(),
  confidence: integer("confidence"),
  language: text("language").default("en-US"),
  duration: integer("duration"), // in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert Schemas
export const insertClinicSettingsSchema = createInsertSchema(clinicSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPrescriptionSchema = createInsertSchema(prescriptions).omit({
  id: true,
  prescriptionId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  medications: z.array(z.object({
    name: z.string(),
    dosage: z.string(),
    duration: z.string(),
    instructions: z.string(),
  })).optional(),
});

export const insertVoiceRecordingSchema = createInsertSchema(voiceRecordings).omit({
  id: true,
  createdAt: true,
});

// Types
export type ClinicSettings = typeof clinicSettings.$inferSelect;
export type InsertClinicSettings = z.infer<typeof insertClinicSettingsSchema>;

export type Patient = typeof patients.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;

export type Prescription = typeof prescriptions.$inferSelect;
export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;

export type VoiceRecording = typeof voiceRecordings.$inferSelect;
export type InsertVoiceRecording = z.infer<typeof insertVoiceRecordingSchema>;

// AI Parsed Data Interface
export interface AIParsedMedicalData {
  patient: {
    name?: string;
    age?: number;
    gender?: string;
    phone?: string;
    address?: string;
  };
  medical: {
    complaints?: string;
    pastHistory?: string;
    currentMeds?: string;
  };
  comorbidities?: {
    htn?: boolean;
    dm?: boolean;
    hypothyroid?: boolean;
    ihd?: boolean;
    cva?: boolean;
  };
  examination?: {
    pulse?: number;
    bp?: string;
    temperature?: number;
    spo2?: number;
    additional?: string;
  };
  menstrual?: {
    lmp?: string;
    cycle?: string;
    details?: string;
  };
  medications?: Array<{
    name: string;
    dosage: string;
    duration: string;
    instructions: string;
  }>;
  nextReviewDate?: string;
  notes?: string;
}
