# MedScript Pro - Medical Prescription Management System

## Overview

MedScript Pro is a comprehensive medical prescription management application that leverages voice recognition and AI to streamline the prescription creation process. The system allows doctors to dictate patient information and medical details through voice input, which is then processed by AI (Google Gemini) to automatically populate structured prescription forms. The application features a modern React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration via Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side is built with React 18 using TypeScript and Vite as the build tool. The UI leverages shadcn/ui component library with Radix UI primitives for accessibility and Tailwind CSS for styling. State management is handled through TanStack Query for server state and React Hook Form with Zod validation for form handling. The application uses Wouter for lightweight client-side routing.

**Key Frontend Design Decisions:**
- **Component Library Choice**: shadcn/ui was selected for its modern design system, accessibility features, and consistent theming capabilities
- **Styling Strategy**: Tailwind CSS with CSS custom properties for theming, allowing dynamic color schemes and responsive design
- **Form Management**: React Hook Form with Zod schemas ensures type-safe form validation and seamless integration with TypeScript
- **State Management**: TanStack Query handles server state caching and synchronization, reducing API calls and improving performance

### Backend Architecture
The server is built with Express.js using TypeScript and follows a modular REST API design. The application implements a storage abstraction layer that currently uses in-memory storage but can be easily extended to work with the configured PostgreSQL database via Drizzle ORM.

**Key Backend Design Decisions:**
- **Storage Abstraction**: Interface-based storage layer allows switching between in-memory and database implementations without code changes
- **API Design**: RESTful endpoints with consistent error handling and request/response logging
- **Database Integration**: Drizzle ORM with PostgreSQL provides type-safe database operations and migration management
- **Development Setup**: Vite integration for hot module replacement in development while serving static files in production

### Voice Recognition & AI Integration
The system integrates browser-based Web Speech API for voice recognition with Google Gemini AI for intelligent parsing of medical transcriptions.

**Key AI/Voice Design Decisions:**
- **Voice Recognition**: Web Speech API provides cross-browser voice input with medical terminology enhancement
- **AI Processing**: Google Gemini 2.5 Flash model parses unstructured voice input into structured medical data
- **Medical Enhancement**: Custom medical terminology dictionary improves voice recognition accuracy for medical terms
- **Confidence Scoring**: Voice recognition confidence levels help users identify potentially inaccurate transcriptions

### Data Management
The application uses a comprehensive schema design that covers clinic settings, patient information, prescriptions, and voice recordings with proper relationships and validation.

**Key Data Design Decisions:**
- **Schema Design**: Drizzle ORM schemas with Zod validation ensure data integrity across the application
- **Relationship Management**: Foreign key relationships between patients, prescriptions, and voice recordings maintain data consistency
- **Audit Trail**: Created/updated timestamps on all major entities provide change tracking
- **Flexible Storage**: Support for both structured prescription data and unstructured voice recordings

### Security & Configuration
The application implements environment-based configuration for API keys and database connections with proper error handling for missing configurations.

**Key Security Design Decisions:**
- **Environment Variables**: Sensitive configuration like API keys and database URLs are externalized
- **Input Validation**: All API endpoints use Zod schemas for request validation
- **Error Handling**: Structured error responses with appropriate HTTP status codes
- **CORS Configuration**: Express server configured for cross-origin requests in development

## External Dependencies

### Core Technologies
- **React 18**: Frontend framework with TypeScript support
- **Express.js**: Backend REST API server
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across frontend and backend

### Database & ORM
- **PostgreSQL**: Primary database (configured via Neon Database)
- **Drizzle ORM**: Type-safe database operations and migrations
- **@neondatabase/serverless**: PostgreSQL client for serverless environments

### UI Framework
- **shadcn/ui**: Component library built on Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library

### AI & Voice Services
- **@google/genai**: Google Gemini AI integration for medical text parsing
- **Web Speech API**: Browser-native voice recognition
- **Medical terminology dictionary**: Custom enhancement for medical voice recognition

### Form & State Management
- **React Hook Form**: Form state management and validation
- **TanStack Query**: Server state management and caching
- **Zod**: Runtime type validation and schema definition
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### PDF Generation
- **jsPDF**: Client-side PDF generation for prescription documents

### Development Tools
- **@replit/vite-plugin-***: Replit-specific development enhancements
- **PostCSS & Autoprefixer**: CSS processing and vendor prefixing