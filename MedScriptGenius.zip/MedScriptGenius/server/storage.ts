import { 
  type ClinicSettings, 
  type InsertClinicSettings, 
  type Patient, 
  type InsertPatient,
  type Prescription,
  type InsertPrescription,
  type VoiceRecording,
  type InsertVoiceRecording
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Clinic Settings
  getClinicSettings(): Promise<ClinicSettings | undefined>;
  upsertClinicSettings(settings: InsertClinicSettings): Promise<ClinicSettings>;
  
  // Patients
  getPatient(id: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  searchPatients(query: string): Promise<Patient[]>;
  
  // Prescriptions
  getPrescription(id: string): Promise<Prescription | undefined>;
  getPrescriptionByPrescriptionId(prescriptionId: string): Promise<Prescription | undefined>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescription(id: string, prescription: Partial<InsertPrescription>): Promise<Prescription>;
  getPrescriptions(limit?: number, offset?: number): Promise<Prescription[]>;
  searchPrescriptions(query: string): Promise<Prescription[]>;
  
  // Voice Recordings
  createVoiceRecording(recording: InsertVoiceRecording): Promise<VoiceRecording>;
  getVoiceRecordings(prescriptionId: string): Promise<VoiceRecording[]>;
}

export class MemStorage implements IStorage {
  private clinicSettings: ClinicSettings | undefined;
  private patients: Map<string, Patient>;
  private prescriptions: Map<string, Prescription>;
  private voiceRecordings: Map<string, VoiceRecording>;
  private prescriptionCounter: number = 1;

  constructor() {
    this.patients = new Map();
    this.prescriptions = new Map();
    this.voiceRecordings = new Map();
  }

  async getClinicSettings(): Promise<ClinicSettings | undefined> {
    return this.clinicSettings;
  }

  async upsertClinicSettings(settings: InsertClinicSettings): Promise<ClinicSettings> {
    const now = new Date();
    if (this.clinicSettings) {
      this.clinicSettings = {
        ...this.clinicSettings,
        ...settings,
        updatedAt: now,
      } as ClinicSettings;
    } else {
      this.clinicSettings = {
        id: randomUUID(),
        ...settings,
        createdAt: now,
        updatedAt: now,
      } as ClinicSettings;
    }
    return this.clinicSettings;
  }

  async getPatient(id: string): Promise<Patient | undefined> {
    return this.patients.get(id);
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const id = randomUUID();
    const now = new Date();
    const patient: Patient = { 
      ...insertPatient, 
      id,
      createdAt: now,
      updatedAt: now,
    } as Patient;
    this.patients.set(id, patient);
    return patient;
  }

  async searchPatients(query: string): Promise<Patient[]> {
    const patients = Array.from(this.patients.values());
    if (!query) return patients;
    
    return patients.filter(patient => 
      patient.name.toLowerCase().includes(query.toLowerCase()) ||
      patient.phone?.includes(query)
    );
  }

  async getPrescription(id: string): Promise<Prescription | undefined> {
    return this.prescriptions.get(id);
  }

  async getPrescriptionByPrescriptionId(prescriptionId: string): Promise<Prescription | undefined> {
    return Array.from(this.prescriptions.values()).find(p => p.prescriptionId === prescriptionId);
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const id = randomUUID();
    const now = new Date();
    const year = now.getFullYear();
    const prescriptionId = `RX-${year}-${String(this.prescriptionCounter++).padStart(3, '0')}`;
    
    const prescription: Prescription = {
      ...insertPrescription,
      id,
      prescriptionId,
      createdAt: now,
      updatedAt: now,
    } as Prescription;
    this.prescriptions.set(id, prescription);
    return prescription;
  }

  async updatePrescription(id: string, updates: Partial<InsertPrescription>): Promise<Prescription> {
    const existing = this.prescriptions.get(id);
    if (!existing) {
      throw new Error(`Prescription with id ${id} not found`);
    }
    
    const updated: Prescription = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    } as Prescription;
    this.prescriptions.set(id, updated);
    return updated;
  }

  async getPrescriptions(limit: number = 50, offset: number = 0): Promise<Prescription[]> {
    const prescriptions = Array.from(this.prescriptions.values())
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    
    return prescriptions.slice(offset, offset + limit);
  }

  async searchPrescriptions(query: string): Promise<Prescription[]> {
    const prescriptions = Array.from(this.prescriptions.values());
    if (!query) return prescriptions;
    
    return prescriptions.filter(prescription => 
      prescription.patientName.toLowerCase().includes(query.toLowerCase()) ||
      prescription.prescriptionId.includes(query) ||
      prescription.presentComplaints?.toLowerCase().includes(query.toLowerCase())
    );
  }

  async createVoiceRecording(insertRecording: InsertVoiceRecording): Promise<VoiceRecording> {
    const id = randomUUID();
    const recording: VoiceRecording = {
      ...insertRecording,
      id,
      createdAt: new Date(),
    } as VoiceRecording;
    this.voiceRecordings.set(id, recording);
    return recording;
  }

  async getVoiceRecordings(prescriptionId: string): Promise<VoiceRecording[]> {
    return Array.from(this.voiceRecordings.values())
      .filter(recording => recording.prescriptionId === prescriptionId)
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }
}

export const storage = new MemStorage();
