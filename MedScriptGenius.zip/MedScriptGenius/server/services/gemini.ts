import { GoogleGenAI } from "@google/genai";
import type { AIParsedMedicalData } from "@shared/schema";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_GEMINI_API_KEY || ""
});

export async function parseMedicalTranscription(transcription: string): Promise<AIParsedMedicalData> {
  if (!transcription || typeof transcription !== 'string') {
    throw new Error('Valid transcription text is required');
  }

  try {
    const systemPrompt = `You are a medical AI assistant specialized in parsing doctor's voice notes into structured prescription data. 

Extract the following information from the medical transcription and return it as JSON:

1. Patient Information:
   - name: full name
   - age: numeric age
   - gender: "male", "female", or "other"
   - phone: contact number if mentioned
   - address: patient address if mentioned

2. Medical Information:
   - complaints: present complaints/symptoms
   - pastHistory: past medical history
   - currentMeds: current medications

3. Comorbidities (boolean flags):
   - htn: hypertension
   - dm: diabetes mellitus
   - hypothyroid: thyroid disorders
   - ihd: ischemic heart disease
   - cva: cerebrovascular accident/stroke

4. Examination findings:
   - pulse: heart rate in bpm (numeric)
   - bp: blood pressure (string like "120/80")
   - temperature: body temperature in Fahrenheit (numeric)
   - spo2: oxygen saturation percentage (numeric)
   - additional: other examination findings

5. Menstrual History (for females only):
   - lmp: last menstrual period date
   - cycle: cycle length information
   - details: additional menstrual history

6. Medications (array of objects):
   - name: medication name with strength
   - dosage: dosing frequency (like "1-0-1")
   - duration: treatment duration
   - instructions: administration instructions

7. Additional:
   - nextReviewDate: follow-up date if mentioned
   - notes: additional instructions or advice

Important parsing rules:
- Convert common medical abbreviations (HTN→hypertension, DM→diabetes, etc.)
- Parse dosage patterns like "once daily"→"1-0-0", "twice daily"→"1-0-1", "three times daily"→"1-1-1"
- Extract vital signs with proper units
- Identify medication names, strengths, and frequencies
- Parse dates in standard format
- If information is not mentioned, omit the field rather than guessing

Return only valid JSON without any explanation or additional text.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            patient: {
              type: "object",
              properties: {
                name: { type: "string" },
                age: { type: "number" },
                gender: { type: "string" },
                phone: { type: "string" },
                address: { type: "string" }
              }
            },
            medical: {
              type: "object",
              properties: {
                complaints: { type: "string" },
                pastHistory: { type: "string" },
                currentMeds: { type: "string" }
              }
            },
            comorbidities: {
              type: "object",
              properties: {
                htn: { type: "boolean" },
                dm: { type: "boolean" },
                hypothyroid: { type: "boolean" },
                ihd: { type: "boolean" },
                cva: { type: "boolean" }
              }
            },
            examination: {
              type: "object",
              properties: {
                pulse: { type: "number" },
                bp: { type: "string" },
                temperature: { type: "number" },
                spo2: { type: "number" },
                additional: { type: "string" }
              }
            },
            menstrual: {
              type: "object",
              properties: {
                lmp: { type: "string" },
                cycle: { type: "string" },
                details: { type: "string" }
              }
            },
            medications: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  dosage: { type: "string" },
                  duration: { type: "string" },
                  instructions: { type: "string" }
                },
                required: ["name", "dosage", "duration", "instructions"]
              }
            },
            nextReviewDate: { type: "string" },
            notes: { type: "string" }
          }
        }
      },
      contents: [
        {
          role: "user",
          parts: [{ text: `Please parse this medical transcription: "${transcription}"` }]
        }
      ]
    });

    const rawJson = response.text;
    console.log('Gemini AI response:', rawJson);

    if (!rawJson) {
      throw new Error('Empty response from Gemini AI');
    }

    try {
      const parsedData: AIParsedMedicalData = JSON.parse(rawJson);
      
      // Validate and clean the parsed data
      const cleanedData: Partial<AIParsedMedicalData> = {};
      
      if (parsedData.patient && Object.keys(parsedData.patient).length > 0) {
        cleanedData.patient = parsedData.patient;
      }
      
      if (parsedData.medical && Object.keys(parsedData.medical).length > 0) {
        cleanedData.medical = parsedData.medical;
      }
      
      if (parsedData.comorbidities && Object.keys(parsedData.comorbidities).length > 0) {
        cleanedData.comorbidities = parsedData.comorbidities;
      }
      
      if (parsedData.examination && Object.keys(parsedData.examination).length > 0) {
        cleanedData.examination = parsedData.examination;
      }
      
      if (parsedData.menstrual && Object.keys(parsedData.menstrual).length > 0) {
        cleanedData.menstrual = parsedData.menstrual;
      }
      
      if (parsedData.medications && Array.isArray(parsedData.medications) && parsedData.medications.length > 0) {
        // Filter out incomplete medications
        const validMedications = parsedData.medications.filter(med => 
          med.name && med.dosage && med.duration && med.instructions
        );
        if (validMedications.length > 0) {
          cleanedData.medications = validMedications;
        }
      }
      
      if (parsedData.nextReviewDate) {
        cleanedData.nextReviewDate = parsedData.nextReviewDate;
      }
      
      if (parsedData.notes) {
        cleanedData.notes = parsedData.notes;
      }
      
      return cleanedData as AIParsedMedicalData;
      
    } catch (parseError) {
      console.error('Failed to parse JSON response from Gemini:', parseError);
      throw new Error('Failed to parse AI response. The transcription may be unclear or incomplete.');
    }

  } catch (error: any) {
    console.error('Gemini AI parsing error:', error);
    
    if (error.message?.includes('API key')) {
      throw new Error('Gemini AI API key is not configured. Please check your environment variables.');
    }
    
    if (error.message?.includes('quota') || error.message?.includes('limit')) {
      throw new Error('Gemini AI quota exceeded. Please try again later.');
    }
    
    if (error.message?.includes('model')) {
      throw new Error('Gemini AI model is not available. Please try again later.');
    }
    
    throw new Error(`Failed to parse medical transcription: ${error.message || 'Unknown error'}`);
  }
}

// Helper function to enhance medical text with common corrections
export function enhanceMedicalText(text: string): string {
  let enhanced = text;
  
  // Common medical term corrections
  const corrections = [
    { from: /\bhigh blood pressure\b/gi, to: 'hypertension' },
    { from: /\bdiabetes mellitus\b/gi, to: 'diabetes' },
    { from: /\bheart disease\b/gi, to: 'IHD' },
    { from: /\bstroke\b/gi, to: 'CVA' },
    { from: /\bonce daily\b/gi, to: '1-0-0' },
    { from: /\btwice daily\b/gi, to: '1-0-1' },
    { from: /\bthree times daily\b/gi, to: '1-1-1' },
    { from: /\bfour times daily\b/gi, to: '1-1-1-1' },
    { from: /\bbefore meals\b/gi, to: 'before food' },
    { from: /\bafter meals\b/gi, to: 'after food' },
    { from: /\bas needed\b/gi, to: 'PRN' },
    { from: /\bwhen required\b/gi, to: 'PRN' },
  ];
  
  corrections.forEach(({ from, to }) => {
    enhanced = enhanced.replace(from, to);
  });
  
  return enhanced;
}
