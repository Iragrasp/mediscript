import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertClinicSettingsSchema, 
  insertPatientSchema, 
  insertPrescriptionSchema,
  insertVoiceRecordingSchema
} from "@shared/schema";
import { parseMedicalTranscription } from "./services/gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Clinic Settings Routes
  app.get("/api/clinic-settings", async (req, res) => {
    try {
      const settings = await storage.getClinicSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get clinic settings" });
    }
  });

  app.post("/api/clinic-settings", async (req, res) => {
    try {
      const validatedData = insertClinicSettingsSchema.parse(req.body);
      const settings = await storage.upsertClinicSettings(validatedData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Invalid clinic settings data", error });
    }
  });

  // Patient Routes
  app.get("/api/patients/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const patients = await storage.searchPatients(query);
      res.json(patients);
    } catch (error) {
      res.status(500).json({ message: "Failed to search patients" });
    }
  });

  app.post("/api/patients", async (req, res) => {
    try {
      const validatedData = insertPatientSchema.parse(req.body);
      const patient = await storage.createPatient(validatedData);
      res.json(patient);
    } catch (error) {
      res.status(400).json({ message: "Invalid patient data", error });
    }
  });

  app.get("/api/patients/:id", async (req, res) => {
    try {
      const patient = await storage.getPatient(req.params.id);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      res.json(patient);
    } catch (error) {
      res.status(500).json({ message: "Failed to get patient" });
    }
  });

  // Prescription Routes
  app.get("/api/prescriptions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const prescriptions = await storage.getPrescriptions(limit, offset);
      res.json(prescriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get prescriptions" });
    }
  });

  app.get("/api/prescriptions/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const prescriptions = await storage.searchPrescriptions(query);
      res.json(prescriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to search prescriptions" });
    }
  });

  app.get("/api/prescriptions/:id", async (req, res) => {
    try {
      const prescription = await storage.getPrescription(req.params.id);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      res.json(prescription);
    } catch (error) {
      res.status(500).json({ message: "Failed to get prescription" });
    }
  });

  app.post("/api/prescriptions", async (req, res) => {
    try {
      const validatedData = insertPrescriptionSchema.parse(req.body);
      const prescription = await storage.createPrescription(validatedData);
      res.json(prescription);
    } catch (error) {
      res.status(400).json({ message: "Invalid prescription data", error });
    }
  });

  app.patch("/api/prescriptions/:id", async (req, res) => {
    try {
      const validatedData = insertPrescriptionSchema.partial().parse(req.body);
      const prescription = await storage.updatePrescription(req.params.id, validatedData);
      res.json(prescription);
    } catch (error) {
      res.status(400).json({ message: "Invalid prescription update data", error });
    }
  });

  // Voice Recording Routes
  app.post("/api/voice-recordings", async (req, res) => {
    try {
      const validatedData = insertVoiceRecordingSchema.parse(req.body);
      const recording = await storage.createVoiceRecording(validatedData);
      res.json(recording);
    } catch (error) {
      res.status(400).json({ message: "Invalid voice recording data", error });
    }
  });

  app.get("/api/voice-recordings/:prescriptionId", async (req, res) => {
    try {
      const recordings = await storage.getVoiceRecordings(req.params.prescriptionId);
      res.json(recordings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get voice recordings" });
    }
  });

  // AI Processing Routes
  app.post("/api/ai/parse-transcription", async (req, res) => {
    try {
      const { transcription } = req.body;
      if (!transcription || typeof transcription !== 'string') {
        return res.status(400).json({ message: "Transcription text is required" });
      }

      const parsedData = await parseMedicalTranscription(transcription);
      res.json(parsedData);
    } catch (error) {
      console.error("AI parsing error:", error);
      res.status(500).json({ message: "Failed to parse transcription with AI" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
