import jsPDF from 'jspdf';

interface PrescriptionData {
  patient: {
    name?: string;
    age?: number;
    gender?: string;
    phone?: string;
    medicalHistory?: string;
    currentSymptoms?: string;
  };
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    route: string;
    instructions?: string;
  }>;
  clinic: {
    name: string;
    specialization: string;
    address: string;
    contact: string;
  };
  doctor: {
    name: string;
    license: string;
  };
}

export async function generatePrescriptionPDF(data: PrescriptionData) {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.getWidth();
  const margin = 20;
  let y = margin;

  // Helper function to add text with wrapping
  const addText = (text: string, x: number, fontSize: number = 12, isBold: boolean = false) => {
    pdf.setFontSize(fontSize);
    pdf.setFont('times', isBold ? 'bold' : 'normal');
    pdf.text(text, x, y);
    y += fontSize * 0.5;
  };

  // Helper function to add line
  const addLine = () => {
    y += 5;
    pdf.line(margin, y, pageWidth - margin, y);
    y += 10;
  };

  // Clinic Header
  pdf.setFontSize(18);
  pdf.setFont('times', 'bold');
  pdf.text(data.clinic.name, pageWidth / 2, y, { align: 'center' });
  y += 15;

  pdf.setFontSize(12);
  pdf.setFont('times', 'normal');
  pdf.text(data.clinic.specialization, pageWidth / 2, y, { align: 'center' });
  y += 10;

  pdf.setFontSize(10);
  pdf.text(data.clinic.address, pageWidth / 2, y, { align: 'center' });
  y += 8;
  pdf.text(data.clinic.contact, pageWidth / 2, y, { align: 'center' });
  y += 15;

  addLine();

  // Prescription Header
  addText('PRESCRIPTION', margin, 16, true);
  y -= 8;
  
  const currentDate = new Date().toLocaleDateString();
  const rxNumber = `RX-${new Date().getFullYear()}-${Math.random().toString().substr(2, 6)}`;
  
  pdf.setFontSize(10);
  pdf.text(`Date: ${currentDate}`, margin, y);
  pdf.text(`Rx #: ${rxNumber}`, pageWidth - margin - 50, y);
  y += 15;

  // Patient Information
  if (data.patient.name) {
    addText('PATIENT INFORMATION', margin, 12, true);
    y += 5;
    
    addText(`Name: ${data.patient.name}`, margin + 10, 10);
    if (data.patient.age || data.patient.gender) {
      let patientDetails = '';
      if (data.patient.age) patientDetails += `Age: ${data.patient.age}`;
      if (data.patient.gender) patientDetails += ` | Gender: ${data.patient.gender}`;
      addText(patientDetails, margin + 10, 10);
    }
    if (data.patient.phone) {
      addText(`Contact: ${data.patient.phone}`, margin + 10, 10);
    }
    y += 10;
  }

  // Medications
  if (data.medications.length > 0) {
    addText('MEDICATIONS', margin, 12, true);
    y += 5;

    data.medications.forEach((medication, index) => {
      addText(`${index + 1}. ${medication.name}`, margin + 10, 11, true);
      addText(`   Sig: Take ${medication.dosage} ${medication.frequency}`, margin + 10, 10);
      if (medication.duration) {
        addText(`   Disp: ${medication.duration} supply`, margin + 10, 10);
      }
      if (medication.instructions) {
        addText(`   Instructions: ${medication.instructions}`, margin + 10, 10);
      }
      y += 5;
    });
  }

  // Doctor Signature Area
  y += 20;
  addText('Doctor\'s Signature: ________________________', margin, 10);
  y += 10;
  addText(data.doctor.name, margin, 10);
  addText(`License #: ${data.doctor.license}`, margin, 10);

  pdf.text('Date: _______________', pageWidth - margin - 50, y - 20);

  // Save the PDF
  const fileName = `prescription_${data.patient.name?.replace(/\s+/g, '_') || 'patient'}_${currentDate.replace(/\//g, '-')}.pdf`;
  pdf.save(fileName);
}
