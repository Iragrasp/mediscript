interface SpeechRecognitionConfig {
  onResult: (text: string, isFinal?: boolean) => void;
  onEnd: () => void;
  onError?: (error: any) => void;
  isRecording?: () => boolean;
}

export function initializeSpeechRecognition(config: SpeechRecognitionConfig): any | null {
  // Check if Web Speech API is supported
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    console.warn('Web Speech API not supported in this browser');
    return null;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();

  // Configure recognition settings
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
  recognition.maxAlternatives = 1;

  let finalTranscript = '';

  recognition.onresult = (event: any) => {
    let interimTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += transcript + ' ';
      } else {
        interimTranscript += transcript;
      }
    }

    // Combine final and interim results
    const fullText = finalTranscript + interimTranscript;
    const hasFinalResults = event.results.length > 0 && event.results[event.results.length - 1].isFinal;
    config.onResult(fullText, hasFinalResults);
  };

  recognition.onend = () => {
    // Auto-restart if still recording (unless stopped intentionally)
    if (config.isRecording && config.isRecording()) {
      setTimeout(() => {
        if (config.isRecording && config.isRecording()) {
          try {
            recognition.start();
          } catch (e) {
            console.warn('Failed to restart speech recognition:', e);
            config.onEnd();
          }
        }
      }, 100);
    } else {
      config.onEnd();
    }
  };

  recognition.onerror = (event: any) => {
    console.error('Speech recognition error:', event.error);
    if (config.onError) {
      config.onError(event.error);
    }
    
    // Auto-restart on recoverable errors
    const recoverableErrors = ['no-speech', 'audio-capture', 'aborted'];
    if (recoverableErrors.includes(event.error) && config.isRecording && config.isRecording()) {
      setTimeout(() => {
        if (config.isRecording && config.isRecording()) {
          try {
            recognition.start();
          } catch (e) {
            console.warn('Failed to restart speech recognition:', e);
          }
        }
      }, 250);
    }
  };

  recognition.onstart = () => {
    finalTranscript = '';
  };

  return recognition;
}

// Extend Window interface for TypeScript
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}
