import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Plus, Trash2 } from "lucide-react";
import { usePrescription } from "@/hooks/use-prescription";
import { useVoiceRecorder } from "@/hooks/use-voice-recorder";

export default function PrescriptionForm() {
  const {
    patientData,
    medications,
    updatePatientData,
    addMedication,
    removeMedication,
    updateMedication,
    showAddForm,
    setShowAddForm,
    newMedication,
    setNewMedication,
    parseAndFillFromAI,
  } = usePrescription();
  
  const { enhancedTranscription } = useVoiceRecorder();

  const handleAddMedication = () => {
    if (newMedication.name && newMedication.dosage && newMedication.frequency) {
      addMedication(newMedication);
      setNewMedication({
        name: "",
        dosage: "",
        frequency: "",
        duration: "",
        route: "Oral",
        instructions: "",
      });
      setShowAddForm(false);
    }
  };
  
  const handleAutoFillFromAI = () => {
    if (enhancedTranscription) {
      const success = parseAndFillFromAI(enhancedTranscription);
      if (success) {
        console.log('Successfully auto-filled from AI transcription');
      }
    } else {
      console.log('No enhanced transcription available. Please record voice first.');
    }
  };

  return (
    <div className="p-4">
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Prescription Details</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-primary"
              onClick={handleAutoFillFromAI}
              disabled={!enhancedTranscription}
              data-testid="button-autofill-ai"
            >
              <Wand2 className="w-4 h-4 mr-1" />
              Auto-fill from AI
            </Button>
          </div>

          {/* Patient Information */}
          <div className="space-y-4 mb-6">
            <h4 className="font-medium text-foreground border-b border-border pb-2">Patient Information</h4>
            
            <div className="grid grid-cols-1 gap-3">
              <div>
                <Label htmlFor="patient-name">Patient Name *</Label>
                <Input
                  id="patient-name"
                  placeholder="Enter patient name"
                  value={patientData.name}
                  onChange={(e) => updatePatientData({ name: e.target.value })}
                  data-testid="input-patient-name"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="patient-age">Age</Label>
                  <Input
                    id="patient-age"
                    type="number"
                    placeholder="Age"
                    value={patientData.age || ""}
                    onChange={(e) => updatePatientData({ age: parseInt(e.target.value) || undefined })}
                    data-testid="input-patient-age"
                  />
                </div>
                <div>
                  <Label htmlFor="patient-gender">Gender</Label>
                  <Select 
                    value={patientData.gender || ""} 
                    onValueChange={(value) => updatePatientData({ gender: value })}
                  >
                    <SelectTrigger data-testid="select-patient-gender">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="patient-phone">Contact Number</Label>
                <Input
                  id="patient-phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={patientData.phone || ""}
                  onChange={(e) => updatePatientData({ phone: e.target.value })}
                  data-testid="input-patient-phone"
                />
              </div>
            </div>
          </div>

          {/* Medical History */}
          <div className="space-y-4 mb-6">
            <h4 className="font-medium text-foreground border-b border-border pb-2">Medical History</h4>
            <div>
              <Label htmlFor="medical-history">Previous Conditions</Label>
              <Textarea
                id="medical-history"
                rows={3}
                placeholder="Previous medical conditions, allergies, etc."
                value={patientData.medicalHistory || ""}
                onChange={(e) => updatePatientData({ medicalHistory: e.target.value })}
                data-testid="textarea-medical-history"
              />
            </div>
            <div>
              <Label htmlFor="current-symptoms">Current Symptoms</Label>
              <Textarea
                id="current-symptoms"
                rows={2}
                placeholder="Current symptoms and complaints"
                value={patientData.currentSymptoms || ""}
                onChange={(e) => updatePatientData({ currentSymptoms: e.target.value })}
                data-testid="textarea-current-symptoms"
              />
            </div>
          </div>

          {/* Medications */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-foreground border-b border-border pb-2 flex-1">Medications</h4>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-primary ml-4"
                onClick={() => setShowAddForm(!showAddForm)}
                data-testid="button-add-medication"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Medication
              </Button>
            </div>

            {/* Existing Medications */}
            {medications.map((medication, index) => (
              <div key={index} className="bg-accent rounded-lg p-3 border border-border">
                <div className="flex items-start justify-between mb-2">
                  <span className="font-medium text-sm text-foreground">{medication.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive/80 h-auto p-1"
                    onClick={() => removeMedication(index)}
                    data-testid={`button-remove-medication-${index}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <span>Dosage: {medication.dosage}</span>
                  <span>Frequency: {medication.frequency}</span>
                  <span>Duration: {medication.duration}</span>
                  <span>Route: {medication.route}</span>
                </div>
                {medication.instructions && (
                  <div className="mt-2 text-xs text-muted-foreground">
                    Instructions: {medication.instructions}
                  </div>
                )}
              </div>
            ))}

            {/* Add New Medication Form */}
            {showAddForm && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="grid grid-cols-1 gap-3">
                  <Input
                    placeholder="Medication name (e.g., Aspirin 81mg)"
                    value={newMedication.name}
                    onChange={(e) => setNewMedication({ ...newMedication, name: e.target.value })}
                    data-testid="input-new-medication-name"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="Dosage"
                      value={newMedication.dosage}
                      onChange={(e) => setNewMedication({ ...newMedication, dosage: e.target.value })}
                      data-testid="input-new-medication-dosage"
                    />
                    <Input
                      placeholder="Frequency"
                      value={newMedication.frequency}
                      onChange={(e) => setNewMedication({ ...newMedication, frequency: e.target.value })}
                      data-testid="input-new-medication-frequency"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="Duration"
                      value={newMedication.duration}
                      onChange={(e) => setNewMedication({ ...newMedication, duration: e.target.value })}
                      data-testid="input-new-medication-duration"
                    />
                    <Select
                      value={newMedication.route}
                      onValueChange={(value) => setNewMedication({ ...newMedication, route: value })}
                    >
                      <SelectTrigger data-testid="select-new-medication-route">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Oral">Oral</SelectItem>
                        <SelectItem value="Injection">Injection</SelectItem>
                        <SelectItem value="Topical">Topical</SelectItem>
                        <SelectItem value="Inhaled">Inhaled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Input
                    placeholder="Special instructions"
                    value={newMedication.instructions || ""}
                    onChange={(e) => setNewMedication({ ...newMedication, instructions: e.target.value })}
                    data-testid="input-new-medication-instructions"
                  />
                  <div className="flex space-x-2">
                    <Button 
                      className="flex-1" 
                      onClick={handleAddMedication}
                      data-testid="button-confirm-add-medication"
                    >
                      Add
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setShowAddForm(false)}
                      data-testid="button-cancel-add-medication"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
