import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Edit, Printer, Mail } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { usePrescription } from "@/hooks/use-prescription";
import { generatePrescriptionPDF } from "@/lib/pdf-generator";

export default function PrescriptionPreview() {
  const { patientData, medications } = usePrescription();

  const handleGeneratePDF = async () => {
    try {
      await generatePrescriptionPDF({
        patient: {
          name: patientData.name,
          age: patientData.age || undefined,
          gender: patientData.gender || undefined,
          phone: patientData.phone || undefined,
          medicalHistory: patientData.medicalHistory || undefined,
          currentSymptoms: patientData.currentSymptoms || undefined,
        },
        medications: medications.map(med => ({
          ...med,
          instructions: med.instructions || undefined
        })),
        clinic: {
          name: "MedCare Clinic",
          specialization: "Internal Medicine & Cardiology",
          address: "123 Medical Center Drive, Suite 456, New York, NY 10001",
          contact: "Phone: (555) 123-4567 | Email: info@medcareclinic.com",
        },
        doctor: {
          name: "Dr. Sarah Johnson, MD",
          license: "MD123456",
        },
      });
    } catch (error) {
      console.error("Failed to generate PDF:", error);
    }
  };

  const handleShareWhatsApp = () => {
    const message = "Please find your prescription attached.";
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const handleShareEmail = () => {
    const subject = "Medical Prescription";
    const body = "Please find your prescription attached.";
    const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(url);
  };

  const handlePrint = () => {
    window.print();
  };

  const currentDate = new Date().toLocaleDateString();
  const rxNumber = `RX-${new Date().getFullYear()}-${Math.random().toString().substr(2, 6)}`;

  return (
    <div className="p-4">
      <Card>
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-4">Prescription Preview</h3>
          
          {/* Prescription Document Preview */}
          <div className="bg-white border-2 border-gray-200 rounded-lg p-4 mb-4 text-black font-serif">
            {/* Clinic Header */}
            <div className="text-center border-b-2 border-gray-300 pb-4 mb-4">
              <h1 className="text-xl font-bold">MedCare Clinic</h1>
              <p className="text-sm">Internal Medicine & Cardiology</p>
              <p className="text-xs mt-1">123 Medical Center Drive, Suite 456, New York, NY 10001</p>
              <p className="text-xs">Phone: (555) 123-4567 | Email: info@medcareclinic.com</p>
            </div>

            {/* Prescription Header */}
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-lg font-bold">PRESCRIPTION</h2>
                <p className="text-sm">Date: {currentDate}</p>
              </div>
              <div className="text-right text-sm">
                <p>Rx #: {rxNumber}</p>
              </div>
            </div>

            {/* Patient Details */}
            {patientData.name && (
              <div className="bg-gray-50 p-3 rounded mb-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Patient:</strong> {patientData.name}<br />
                    {patientData.age && <><strong>Age:</strong> {patientData.age}</>}
                    {patientData.gender && <> | <strong>Gender:</strong> {patientData.gender}</>}
                  </div>
                  {patientData.phone && (
                    <div>
                      <strong>Contact:</strong> {patientData.phone}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Medications */}
            {medications.length > 0 && (
              <div className="mb-4">
                <h3 className="font-bold mb-2 text-base">Rx:</h3>
                <div className="space-y-3">
                  {medications.map((medication, index) => (
                    <div key={index} className="border-l-4 border-blue-500 pl-3">
                      <p className="font-semibold">{index + 1}. {medication.name}</p>
                      <p className="text-sm">Sig: Take {medication.dosage} {medication.frequency}</p>
                      {medication.duration && <p className="text-sm">Disp: {medication.duration} supply</p>}
                      {medication.instructions && <p className="text-sm">Instructions: {medication.instructions}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Doctor Signature Area */}
            <div className="mt-8 pt-4 border-t border-gray-300">
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-sm mb-1">Doctor's Signature:</p>
                  <div className="border-b border-black w-48 h-8 mb-2"></div>
                  <p className="text-xs">Dr. Sarah Johnson, MD</p>
                  <p className="text-xs">License #: MD123456</p>
                </div>
                <div className="text-right text-xs">
                  <p>Date: _______________</p>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Button 
                className="flex items-center justify-center"
                onClick={handleGeneratePDF}
                data-testid="button-generate-pdf"
              >
                <FileText className="w-4 h-4 mr-2" />
                Generate PDF
              </Button>
              <Button 
                variant="secondary" 
                className="flex items-center justify-center"
                data-testid="button-edit-prescription"
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="flex items-center justify-center"
                onClick={handleShareWhatsApp}
                data-testid="button-share-whatsapp"
              >
                <SiWhatsapp className="w-4 h-4 mr-2 text-green-600" />
                WhatsApp
              </Button>
              <Button 
                variant="outline" 
                className="flex items-center justify-center"
                onClick={handleShareEmail}
                data-testid="button-share-email"
              >
                <Mail className="w-4 h-4 mr-2" />
                Email
              </Button>
            </div>

            <Button 
              variant="secondary" 
              className="w-full flex items-center justify-center"
              onClick={handlePrint}
              data-testid="button-print-prescription"
            >
              <Printer className="w-4 h-4 mr-2" />
              Print Prescription
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
