import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Mic, Square, Play, Bot, Sparkles } from "lucide-react";
import { useVoiceRecorder } from "@/hooks/use-voice-recorder";
import { cn } from "@/lib/utils";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VoiceRecorderProps {
  isActive?: boolean;
}

export default function VoiceRecorder({ isActive = true }: VoiceRecorderProps) {
  const [manualInput, setManualInput] = useState("");
  const [manualEnhanced, setManualEnhanced] = useState("");
  
  const {
    isRecording,
    isProcessing,
    transcription,
    recordingTime,
    startRecording,
    stopRecording,
    playRecording,
    canPlay,
    speechError,
  } = useVoiceRecorder();

  // Manual AI enhancement mutation
  const manualEnhanceMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest("POST", "/api/enhance-transcription", { transcription: text });
      return response.json();
    },
    onSuccess: (data) => {
      setManualEnhanced(data.enhanced);
    },
    onError: (error) => {
      console.error("Failed to enhance transcription:", error);
    },
  });

  // Stop recording when component becomes inactive
  useEffect(() => {
    if (!isActive && isRecording) {
      stopRecording();
    }
  }, [isActive, isRecording, stopRecording]);

  const handleManualEnhance = () => {
    const textToEnhance = manualInput.trim();
    if (textToEnhance) {
      manualEnhanceMutation.mutate(textToEnhance);
    }
  };

  const handleTranscriptionEnhance = () => {
    if (transcription.trim()) {
      manualEnhanceMutation.mutate(transcription.trim());
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-4">
      <Card className="mb-4">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold mb-2">Voice Prescription</h2>
            <p className="text-muted-foreground text-sm">Start recording to dictate prescription details</p>
          </div>

          {/* Recording Status */}
          {isRecording && (
            <div className="flex justify-center mb-6">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 w-full">
                <div className="flex items-center justify-center space-x-2 mb-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-red-700 font-medium">Recording...</span>
                  <span className="text-red-600 text-sm">{formatTime(recordingTime)}</span>
                </div>
                {/* Voice wave visualization */}
                <div className="flex justify-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "w-1 bg-red-400 rounded-full",
                        "animate-pulse"
                      )}
                      style={{
                        height: Math.random() * 20 + 20 + "px",
                        animationDelay: `${i * 0.1}s`,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Voice Controls */}
          <div className="flex justify-center space-x-4 mb-6">
            <Button
              size="lg"
              className={cn(
                "w-16 h-16 rounded-full text-2xl",
                isRecording && "hidden"
              )}
              onClick={startRecording}
              data-testid="button-start-recording"
            >
              <Mic />
            </Button>
            
            <Button
              size="lg"
              variant="destructive"
              className={cn(
                "w-16 h-16 rounded-full text-2xl",
                !isRecording && "hidden"
              )}
              onClick={stopRecording}
              data-testid="button-stop-recording"
            >
              <Square />
            </Button>
            
            <Button
              size="sm"
              variant="secondary"
              className="w-12 h-12 rounded-full"
              onClick={playRecording}
              disabled={!canPlay}
              data-testid="button-play-recording"
            >
              <Play className="w-4 h-4" />
            </Button>
          </div>

          {/* Transcription Display */}
          <div className="bg-muted rounded-lg p-4 min-h-[100px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-muted-foreground">Live Transcription</span>
              <div className="flex items-center gap-2">
                {isProcessing && (
                  <span className="text-xs text-blue-600 dark:text-blue-400 flex items-center">
                    <Bot className="w-3 h-3 mr-1 animate-spin" />
                    Enhancing...
                  </span>
                )}
                {speechError && (
                  <span className="text-xs text-amber-600 dark:text-amber-400 flex items-center">
                    <span>Speech: {speechError}</span>
                  </span>
                )}
                <Button
                  onClick={handleTranscriptionEnhance}
                  disabled={manualEnhanceMutation.isPending || !transcription.trim()}
                  size="sm"
                  variant="outline"
                  className="h-6 text-xs"
                >
                  {manualEnhanceMutation.isPending ? (
                    <Bot className="w-3 h-3 animate-spin" />
                  ) : (
                    <Sparkles className="w-3 h-3" />
                  )}
                  Enhance
                </Button>
              </div>
            </div>
            <div className="text-sm text-foreground min-h-[60px]" data-testid="text-transcription">
              {transcription || (
                <span className="text-muted-foreground italic">
                  Start speaking to see transcription...
                </span>
              )}
            </div>
            
            {/* Error feedback */}
            {speechError === 'not-allowed' && (
              <div className="mt-2 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-2 rounded border border-red-200 dark:border-red-800">
                Please allow microphone access to use voice recording
              </div>
            )}
          </div>
          
          {/* Manual Text Input */}
          <div className="mt-4 bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
            <h4 className="text-sm font-medium mb-2 text-green-700 dark:text-green-300">Manual Entry</h4>
            <div className="space-y-2">
              <div className="flex gap-2">
                <textarea
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  placeholder="Type medical notes here (e.g., HTN, DM, BID, QID)..."
                  className="flex-1 text-sm border rounded px-3 py-2 bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600"
                  rows={3}
                />
                <Button
                  onClick={handleManualEnhance}
                  disabled={manualEnhanceMutation.isPending || !manualInput.trim()}
                  size="sm"
                  className="self-start mt-1"
                >
                  {manualEnhanceMutation.isPending ? (
                    <Bot className="w-3 h-3 animate-spin" />
                  ) : (
                    <Sparkles className="w-3 h-3" />
                  )}
                  Enhance
                </Button>
              </div>
              {manualEnhanced && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800">
                  <span className="text-xs font-medium text-blue-700 dark:text-blue-300">AI Enhanced:</span>
                  <p className="text-sm text-blue-900 dark:text-blue-100 mt-1">{manualEnhanced}</p>
                </div>
              )}
            </div>
          </div>

          {/* AI Processing Status */}
          {isProcessing && (
            <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
                <span className="text-blue-700 text-sm">AI processing medical terminology...</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
