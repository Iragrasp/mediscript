import { Mic, FileText, Users, BarChart3 } from "lucide-react";
import { cn } from "@/lib/utils";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "record", icon: Mic, label: "Record" },
    { id: "prescriptions", icon: FileText, label: "Prescriptions" },
    { id: "patients", icon: Users, label: "Patients" },
    { id: "reports", icon: BarChart3, label: "Reports" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border px-4 py-2">
      <div className="max-w-md mx-auto">
        <div className="flex justify-around items-center">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                className={cn(
                  "flex flex-col items-center py-2 px-3 rounded-lg transition-colors",
                  activeTab === tab.id ? "text-primary" : "text-muted-foreground"
                )}
                onClick={() => onTabChange(tab.id)}
                data-testid={`button-nav-${tab.id}`}
              >
                <Icon className="w-5 h-5 mb-1" />
                <span className="text-xs">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
