import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Upload, Settings, Hospital } from "lucide-react";

export default function ClinicSettings() {
  return (
    <div className="p-4">
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Clinic Header</h3>
            <Button variant="ghost" size="sm" className="text-primary">
              <Edit className="w-4 h-4 mr-1" />
              Edit
            </Button>
          </div>

          <div className="bg-accent rounded-lg p-4 border border-border">
            {/* Clinic Header Preview */}
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-primary rounded-lg mx-auto flex items-center justify-center mb-3">
                <Hospital className="text-primary-foreground text-2xl" />
              </div>
              <h2 className="text-lg font-bold text-foreground">MedCare Clinic</h2>
              <p className="text-sm text-muted-foreground">Internal Medicine & Cardiology</p>
              <div className="text-xs text-muted-foreground space-y-1">
                <p>123 Medical Center Drive, Suite 456</p>
                <p>New York, NY 10001</p>
                <p>Phone: (555) 123-4567 | Email: info@medcareclinic.com</p>
              </div>
            </div>
          </div>

          <div className="mt-3 flex space-x-2">
            <Button variant="secondary" className="flex-1" data-testid="button-upload-logo">
              <Upload className="w-4 h-4 mr-1" />
              Upload Logo
            </Button>
            <Button variant="outline" className="flex-1" data-testid="button-clinic-settings">
              <Settings className="w-4 h-4 mr-1" />
              Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
