import { useState } from "react";
import VoiceRecorder from "@/components/voice-recorder";
import PrescriptionForm from "@/components/prescription-form";
import ClinicSettings from "@/components/clinic-settings";
import PrescriptionPreview from "@/components/prescription-preview";
import BottomNavigation from "@/components/bottom-navigation";
import { Stethoscope, Settings } from "lucide-react";
import { useVoiceRecorder } from "@/hooks/use-voice-recorder";

export default function Home() {
  const [activeTab, setActiveTab] = useState("record");
  
  // Hoist voice recorder state to share between components
  const voiceRecorderState = useVoiceRecorder();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 py-3 sticky top-0 z-50">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="flex items-center space-x-3">
            <Stethoscope className="text-primary text-xl" />
            <h1 className="text-lg font-semibold text-foreground">MediScribe</h1>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              className="p-2 text-muted-foreground hover:text-foreground rounded-md"
              data-testid="button-settings"
            >
              <Settings className="w-5 h-5" />
            </button>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground text-sm font-medium">Dr</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto pb-20">
        {/* Record Tab - Always mounted but hidden when inactive */}
        <div className={activeTab === "record" ? "block" : "hidden"}>
          <VoiceRecorder isActive={activeTab === "record"} />
          <PrescriptionForm />
          <ClinicSettings />
          <PrescriptionPreview />
        </div>
        
        {/* Prescriptions Tab */}
        <div className={activeTab === "prescriptions" ? "block" : "hidden"}>
          <div className="p-4">
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <h3 className="text-lg font-semibold mb-2">Prescriptions</h3>
              <p className="text-muted-foreground">View and manage your prescriptions here.</p>
            </div>
          </div>
        </div>
        
        {/* Patients Tab */}
        <div className={activeTab === "patients" ? "block" : "hidden"}>
          <div className="p-4">
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <h3 className="text-lg font-semibold mb-2">Patients</h3>
              <p className="text-muted-foreground">Manage your patient records here.</p>
            </div>
          </div>
        </div>
        
        {/* Reports Tab */}
        <div className={activeTab === "reports" ? "block" : "hidden"}>
          <div className="p-4">
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <h3 className="text-lg font-semibold mb-2">Reports</h3>
              <p className="text-muted-foreground">View analytics and reports here.</p>
            </div>
          </div>
        </div>
      </main>

      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
