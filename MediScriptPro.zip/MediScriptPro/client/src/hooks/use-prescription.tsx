import { useState } from "react";
import type { InsertPatient, InsertMedication } from "@shared/schema";

interface MedicationForm {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  route: string;
  instructions?: string;
}

export function usePrescription() {
  const [patientData, setPatientData] = useState<Partial<InsertPatient>>({});
  const [medications, setMedications] = useState<MedicationForm[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMedication, setNewMedication] = useState<MedicationForm>({
    name: "",
    dosage: "",
    frequency: "",
    duration: "",
    route: "Oral",
    instructions: "",
  });

  const updatePatientData = (updates: Partial<InsertPatient>) => {
    setPatientData(prev => ({ ...prev, ...updates }));
  };

  const addMedication = (medication: MedicationForm) => {
    setMedications(prev => [...prev, medication]);
  };

  const removeMedication = (index: number) => {
    setMedications(prev => prev.filter((_, i) => i !== index));
  };

  const updateMedication = (index: number, updates: Partial<MedicationForm>) => {
    setMedications(prev => 
      prev.map((med, i) => i === index ? { ...med, ...updates } : med)
    );
  };

  const resetForm = () => {
    setPatientData({});
    setMedications([]);
    setShowAddForm(false);
    setNewMedication({
      name: "",
      dosage: "",
      frequency: "",
      duration: "",
      route: "Oral",
      instructions: "",
    });
  };

  const parseAndFillFromAI = (enhancedText: string) => {
    try {
      // Extract patient information
      const nameMatch = enhancedText.match(/\*\*Patient Name:\*\*\s*(.+?)(?:\n|\*\*|$)/i);
      const ageMatch = enhancedText.match(/\*\*Age:\*\*\s*(\d+)/i);
      const genderMatch = enhancedText.match(/\*\*Gender:\*\*\s*(male|female|other)/i);
      const phoneMatch = enhancedText.match(/\*\*Contact Number:\*\*\s*(.+?)(?:\n|\*\*|$)/i);
      
      // Extract medical history
      const historyMatch = enhancedText.match(/\*\*(?:Past )?Medical History:\*\*\s*([\s\S]*?)(?:\*\*|$)/i);
      const symptomsMatch = enhancedText.match(/\*\*Current Symptoms?:\*\*\s*([\s\S]*?)(?:\*\*|$)/i);
      
      // Build patient data object
      const updatedPatientData: Partial<InsertPatient> = {};
      
      if (nameMatch) {
        updatedPatientData.name = nameMatch[1].trim();
      }
      
      if (ageMatch) {
        updatedPatientData.age = parseInt(ageMatch[1]);
      }
      
      if (genderMatch) {
        updatedPatientData.gender = genderMatch[1].toLowerCase();
      }
      
      if (phoneMatch) {
        updatedPatientData.phone = phoneMatch[1].trim();
      }
      
      if (historyMatch) {
        updatedPatientData.medicalHistory = historyMatch[1]
          .split('\n')
          .map(line => line.trim())
          .filter(line => line && !line.startsWith('**'))
          .join(', ');
      }
      
      if (symptomsMatch) {
        updatedPatientData.currentSymptoms = symptomsMatch[1]
          .split('\n')
          .map(line => line.trim())
          .filter(line => line && !line.startsWith('**'))
          .join(', ');
      }
      
      // Update patient data
      setPatientData(prev => ({ ...prev, ...updatedPatientData }));
      
      // Extract medications
      const medicationsMatch = enhancedText.match(/\*\*(?:Current )?Medications?:\*\*\s*([\s\S]*?)(?:\*\*|$)/i);
      if (medicationsMatch) {
        const medicationText = medicationsMatch[1];
        const medicationLines = medicationText
          .split('\n')
          .map(line => line.trim())
          .filter(line => line && !line.startsWith('**'));
        
        const parsedMedications: MedicationForm[] = [];
        
        medicationLines.forEach(line => {
          // Parse medication lines like "Metformin 500mg, by mouth, twice daily"
          const parts = line.split(',').map(p => p.trim());
          if (parts.length > 0) {
            const nameAndDosage = parts[0];
            const route = parts.find(p => p.includes('mouth') || p.includes('oral')) ? 'Oral' : 'Oral';
            const frequency = parts.find(p => 
              p.includes('daily') || p.includes('twice') || p.includes('once') || 
              p.includes('bid') || p.includes('tid') || p.includes('qid')
            ) || 'once daily';
            
            // Extract medication name and dosage
            const dosageMatch = nameAndDosage.match(/(.+?)\s+(\d+\s*mg|mg)/i);
            const name = dosageMatch ? dosageMatch[1].trim() : nameAndDosage;
            const dosage = dosageMatch ? dosageMatch[2] : '1 tablet';
            
            parsedMedications.push({
              name: name,
              dosage: dosage,
              frequency: frequency,
              duration: '30 days',
              route: route,
              instructions: ''
            });
          }
        });
        
        // Add parsed medications to existing ones
        setMedications(prev => [...prev, ...parsedMedications]);
      }
      
      return true;
    } catch (error) {
      console.error('Error parsing AI text:', error);
      return false;
    }
  };

  return {
    patientData,
    medications,
    showAddForm,
    newMedication,
    updatePatientData,
    addMedication,
    removeMedication,
    updateMedication,
    setShowAddForm,
    setNewMedication,
    resetForm,
    parseAndFillFromAI,
  };
}
