import { useState, useEffect, useRef, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { initializeSpeechRecognition } from "@/lib/speech-api";

// Debounce utility
function useDebounce<T extends (...args: any[]) => any>(func: T, delay: number) {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  return useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      func(...args);
    }, delay);
  }, [func, delay]);
}

export function useVoiceRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [rawTranscription, setRawTranscription] = useState("");
  const [enhancedTranscription, setEnhancedTranscription] = useState("");
  const [recordingTime, setRecordingTime] = useState(0);
  const [canPlay, setCanPlay] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  
  const isRecordingRef = useRef(false);
  const streamRef = useRef<MediaStream | null>(null);
  
  const recognitionRef = useRef<any | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const enhanceTranscriptionMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest("POST", "/api/enhance-transcription", { transcription: text });
      return response.json();
    },
    onSuccess: (data) => {
      setEnhancedTranscription(data.enhanced);
      setIsProcessing(false);
    },
    onError: (error) => {
      console.error("Failed to enhance transcription:", error);
      setIsProcessing(false);
    },
  });

  // Stable debounced enhancement with useRef timer
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const debouncedEnhance = useCallback((text: string, isFinal: boolean) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    
    // Only enhance final results to reduce API calls
    if (isFinal && text.trim() && !enhanceTranscriptionMutation.isPending && isRecordingRef.current) {
      debounceTimerRef.current = setTimeout(() => {
        setIsProcessing(true);
        enhanceTranscriptionMutation.mutate(text.trim());
      }, 1500);
    }
  }, [enhanceTranscriptionMutation]);

  useEffect(() => {
    // Initialize speech recognition once on mount
    recognitionRef.current = initializeSpeechRecognition({
      onResult: (text, isFinal) => {
        setRawTranscription(text);
        setSpeechError(null); // Clear any previous errors
        
        // Trigger debounced AI enhancement for final results only
        debouncedEnhance(text, isFinal);
      },
      onEnd: () => {
        // This is now handled by the speech-api auto-restart logic
      },
      onError: (error) => {
        setSpeechError(error);
        console.warn('Speech recognition error:', error);
      },
      isRecording: () => isRecordingRef.current,
    });

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []); // Empty deps - initialize once

  const startRecording = async () => {
    try {
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      // Initialize media recorder for audio recording
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        setCanPlay(true);
        // You can save or process the audio blob here
      };

      // Start recording
      mediaRecorderRef.current.start();
      setIsRecording(true);
      isRecordingRef.current = true;
      setRecordingTime(0);
      setRawTranscription("");
      setEnhancedTranscription("");
      setCanPlay(false);

      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);

      // Start speech recognition
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }
    } catch (error) {
      console.error("Failed to start recording:", error);
    }
  };

  const stopRecording = () => {
    setIsRecording(false);
    isRecordingRef.current = false;

    // Stop timer
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    // Stop media recorder
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }

    // Stop speech recognition
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }

    // Stop media stream tracks properly
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    // Final AI enhancement pass (in case debounced one didn't run)
    setTimeout(() => {
      if (rawTranscription.trim() && !enhanceTranscriptionMutation.isPending) {
        setIsProcessing(true);
        enhanceTranscriptionMutation.mutate(rawTranscription.trim());
      }
    }, 500);
  };

  const playRecording = () => {
    // TODO: Implement audio playback
    console.log("Playing recorded audio...");
  };

  return {
    isRecording,
    isProcessing,
    transcription: rawTranscription,
    enhancedTranscription,
    recordingTime,
    canPlay,
    speechError,
    startRecording,
    stopRecording,
    playRecording,
  };
}
