# Overview

MediScribe is a medical transcription and prescription management web application designed to help healthcare professionals create, manage, and generate prescriptions through voice recording and AI enhancement. The application combines voice-to-text transcription with AI-powered medical text processing to streamline the prescription creation workflow for clinics and medical practitioners.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built as a React single-page application using TypeScript and Vite for build tooling. The architecture follows a component-based design with:

- **UI Framework**: React with TypeScript for type safety
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: React hooks and TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Mobile-First Design**: Bottom navigation pattern optimized for mobile medical workflows

## Backend Architecture
The server follows a REST API pattern built with Node.js and Express:

- **Runtime**: Node.js with ES modules
- **Framework**: Express.js for HTTP server and API routing
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **File Handling**: Multer middleware for image upload processing
- **Development**: Hot module replacement via Vite middleware integration

## Data Storage Solutions
The application uses a hybrid storage approach:

- **Primary Database**: PostgreSQL with Drizzle ORM for schema management and type safety
- **Connection**: Neon Database serverless PostgreSQL for scalable cloud hosting
- **Development Storage**: In-memory storage implementation for rapid prototyping
- **File Storage**: Local filesystem for uploaded medical images with 5MB size limits

The database schema includes four main entities:
- Clinics (practice information and branding)
- Patients (demographics and medical history)
- Medications (drug information and dosing)
- Prescriptions (linking patients to medications with metadata)

## Authentication and Authorization
Currently implements a stateless approach with session-based authentication using:

- **Session Management**: PostgreSQL session store via connect-pg-simple
- **Security**: Express built-in security with CORS and request validation
- **Future Considerations**: Designed to accommodate role-based access control for multi-clinic deployments

## Voice Processing and AI Integration
The application integrates multiple AI services for medical transcription:

- **Speech Recognition**: Browser Web Speech API for real-time voice-to-text conversion
- **AI Enhancement**: Google Gemini API for medical terminology correction and prescription formatting
- **Medical Context**: Specialized prompts for expanding medical abbreviations and standardizing drug names
- **Error Handling**: Graceful fallbacks when AI services are unavailable

## PDF Generation and Document Management
Client-side document generation for prescription printing:

- **PDF Creation**: jsPDF library for generating formatted prescriptions
- **Template System**: Structured prescription layouts with clinic branding
- **Sharing Options**: WhatsApp and email integration for digital prescription delivery
- **Print Optimization**: Mobile-friendly PDF layouts for various paper sizes

# External Dependencies

## Core Technologies
- **Database**: Neon Database (serverless PostgreSQL)
- **AI Service**: Google Gemini API for medical text enhancement
- **Build System**: Vite with Replit-specific plugins for development environment

## UI and Styling
- **Component Library**: Radix UI primitives with shadcn/ui theming
- **Icons**: Lucide React and React Icons for consistent iconography
- **Fonts**: Google Fonts integration (Open Sans, DM Sans, Fira Code)
- **CSS Framework**: Tailwind CSS with custom design tokens

## Development Tools
- **Type Checking**: TypeScript with strict configuration
- **Database Migration**: Drizzle Kit for schema management
- **Code Quality**: ESBuild for production bundling
- **Development Server**: Express with Vite middleware for hot reloading

## Third-Party Integrations
- **File Upload**: Multer for image processing with type validation
- **Session Storage**: connect-pg-simple for PostgreSQL session management
- **Date Handling**: date-fns for medical appointment and prescription date formatting
- **PDF Generation**: jsPDF for client-side document creation
- **Voice Recognition**: Browser Web Speech API (Chrome/Safari compatibility)