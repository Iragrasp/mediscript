import { type Clinic, type Patient, type Medication, type Prescription, type InsertClinic, type InsertPatient, type InsertMedication, type InsertPrescription } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Clinic operations
  getClinic(id: string): Promise<Clinic | undefined>;
  createClinic(clinic: InsertClinic): Promise<Clinic>;
  updateClinic(id: string, clinic: Partial<InsertClinic>): Promise<Clinic | undefined>;
  
  // Patient operations
  getPatient(id: string): Promise<Patient | undefined>;
  createPatient(patient: InsertPatient): Promise<Patient>;
  updatePatient(id: string, patient: Partial<InsertPatient>): Promise<Patient | undefined>;
  searchPatients(query: string): Promise<Patient[]>;
  
  // Medication operations
  getMedication(id: string): Promise<Medication | undefined>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: string, medication: Partial<InsertMedication>): Promise<Medication | undefined>;
  deleteMedication(id: string): Promise<boolean>;
  
  // Prescription operations
  getPrescription(id: string): Promise<Prescription | undefined>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescription(id: string, prescription: Partial<InsertPrescription>): Promise<Prescription | undefined>;
  getPrescriptionsByPatient(patientId: string): Promise<Prescription[]>;
}

export class MemStorage implements IStorage {
  private clinics: Map<string, Clinic>;
  private patients: Map<string, Patient>;
  private medications: Map<string, Medication>;
  private prescriptions: Map<string, Prescription>;

  constructor() {
    this.clinics = new Map();
    this.patients = new Map();
    this.medications = new Map();
    this.prescriptions = new Map();

    // Initialize with default clinic
    this.initializeDefaultClinic();
  }

  private async initializeDefaultClinic(): Promise<void> {
    const defaultClinic: Clinic = {
      id: randomUUID(),
      name: "MedCare Clinic",
      specialization: "Internal Medicine & Cardiology",
      address: "123 Medical Center Drive, Suite 456",
      cityState: "New York, NY 10001",
      contact: "Phone: (555) 123-4567 | Email: info@medcareclinic.com",
      logoUrl: null,
      doctorName: "Dr. Sarah Johnson, MD",
      doctorLicense: "MD123456",
    };
    this.clinics.set(defaultClinic.id, defaultClinic);
  }

  // Clinic operations
  async getClinic(id: string): Promise<Clinic | undefined> {
    return this.clinics.get(id);
  }

  async createClinic(insertClinic: InsertClinic): Promise<Clinic> {
    const id = randomUUID();
    const clinic: Clinic = { 
      id,
      name: insertClinic.name,
      specialization: insertClinic.specialization || null,
      address: insertClinic.address || null,
      cityState: insertClinic.cityState || null,
      contact: insertClinic.contact || null,
      logoUrl: insertClinic.logoUrl || null,
      doctorName: insertClinic.doctorName || null,
      doctorLicense: insertClinic.doctorLicense || null,
    };
    this.clinics.set(id, clinic);
    return clinic;
  }

  async updateClinic(id: string, updateData: Partial<InsertClinic>): Promise<Clinic | undefined> {
    const clinic = this.clinics.get(id);
    if (!clinic) return undefined;
    
    const updatedClinic = { ...clinic, ...updateData };
    this.clinics.set(id, updatedClinic);
    return updatedClinic;
  }

  // Patient operations
  async getPatient(id: string): Promise<Patient | undefined> {
    return this.patients.get(id);
  }

  async createPatient(insertPatient: InsertPatient): Promise<Patient> {
    const id = randomUUID();
    const patient: Patient = { 
      id,
      name: insertPatient.name,
      age: insertPatient.age || null,
      gender: insertPatient.gender || null,
      phone: insertPatient.phone || null,
      medicalHistory: insertPatient.medicalHistory || null,
      currentSymptoms: insertPatient.currentSymptoms || null,
    };
    this.patients.set(id, patient);
    return patient;
  }

  async updatePatient(id: string, updateData: Partial<InsertPatient>): Promise<Patient | undefined> {
    const patient = this.patients.get(id);
    if (!patient) return undefined;
    
    const updatedPatient = { ...patient, ...updateData };
    this.patients.set(id, updatedPatient);
    return updatedPatient;
  }

  async searchPatients(query: string): Promise<Patient[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.patients.values()).filter(
      (patient) =>
        patient.name.toLowerCase().includes(lowerQuery) ||
        patient.phone?.toLowerCase().includes(lowerQuery)
    );
  }

  // Medication operations
  async getMedication(id: string): Promise<Medication | undefined> {
    return this.medications.get(id);
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const id = randomUUID();
    const medication: Medication = { 
      id,
      name: insertMedication.name,
      dosage: insertMedication.dosage,
      frequency: insertMedication.frequency,
      duration: insertMedication.duration,
      route: insertMedication.route,
      instructions: insertMedication.instructions || null,
    };
    this.medications.set(id, medication);
    return medication;
  }

  async updateMedication(id: string, updateData: Partial<InsertMedication>): Promise<Medication | undefined> {
    const medication = this.medications.get(id);
    if (!medication) return undefined;
    
    const updatedMedication = { ...medication, ...updateData };
    this.medications.set(id, updatedMedication);
    return updatedMedication;
  }

  async deleteMedication(id: string): Promise<boolean> {
    return this.medications.delete(id);
  }

  // Prescription operations
  async getPrescription(id: string): Promise<Prescription | undefined> {
    return this.prescriptions.get(id);
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const id = randomUUID();
    const prescription: Prescription = { 
      id,
      patientId: insertPrescription.patientId,
      clinicId: insertPrescription.clinicId,
      medications: insertPrescription.medications,
      transcription: insertPrescription.transcription || null,
      enhancedTranscription: insertPrescription.enhancedTranscription || null,
      date: new Date()
    };
    this.prescriptions.set(id, prescription);
    return prescription;
  }

  async updatePrescription(id: string, updateData: Partial<InsertPrescription>): Promise<Prescription | undefined> {
    const prescription = this.prescriptions.get(id);
    if (!prescription) return undefined;
    
    const updatedPrescription: Prescription = { 
      ...prescription,
      ...updateData,
      transcription: updateData.transcription !== undefined ? updateData.transcription || null : prescription.transcription,
      enhancedTranscription: updateData.enhancedTranscription !== undefined ? updateData.enhancedTranscription || null : prescription.enhancedTranscription,
    };
    this.prescriptions.set(id, updatedPrescription);
    return updatedPrescription;
  }

  async getPrescriptionsByPatient(patientId: string): Promise<Prescription[]> {
    return Array.from(this.prescriptions.values()).filter(
      (prescription) => prescription.patientId === patientId
    );
  }
}

export const storage = new MemStorage();
