import { GoogleGenAI } from "@google/genai";

// Initialize Gemini AI client
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || "" 
});

interface EnhancedMedicalTranscription {
  patientInfo: {
    name?: string;
    age?: number;
    gender?: string;
    phone?: string;
  };
  medicalHistory?: string;
  currentSymptoms?: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    route: string;
    instructions?: string;
  }>;
  enhancedText: string;
  originalText: string;
}

export async function enhanceMedicalTranscription(rawTranscription: string): Promise<string> {
  try {
    if (!rawTranscription.trim()) {
      throw new Error("Empty transcription provided");
    }

    const systemPrompt = `You are a medical transcription AI specialist with expertise in clinical terminology, medication names, and prescription formatting. 

Your task is to enhance and correct medical transcriptions by:
1. Correcting medical terminology and medication names
2. Converting common abbreviations to proper medical terms
3. Standardizing dosages, frequencies, and routes of administration
4. Maintaining clinical accuracy and proper medical formatting
5. Preserving all patient information mentioned

Common medical abbreviations to expand:
- PMH = Past Medical History
- HTN = Hypertension  
- T2DM = Type 2 Diabetes Mellitus
- DM = Diabetes Mellitus
- CAD = Coronary Artery Disease
- CHF = Congestive Heart Failure
- COPD = Chronic Obstructive Pulmonary Disease
- UTI = Urinary Tract Infection
- PO = By mouth/Oral
- BID = Twice daily
- TID = Three times daily  
- QID = Four times daily
- QD/Daily = Once daily
- PRN = As needed
- mg = milligrams
- mcg = micrograms
- ml = milliliters

Ensure medication names are spelled correctly and include proper dosage formatting.
Maintain the original meaning while improving medical accuracy and readability.

Return only the enhanced transcription text, properly formatted for medical use.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3, // Lower temperature for more consistent medical terminology
      },
      contents: [
        {
          role: "user",
          parts: [{ text: `Please enhance this medical transcription:\n\n${rawTranscription}` }]
        }
      ],
    });

    const enhancedText = response.text;
    
    if (!enhancedText) {
      throw new Error("No response received from Gemini AI");
    }

    console.log(`Enhanced transcription: ${enhancedText.substring(0, 100)}...`);
    return enhancedText.trim();

  } catch (error) {
    console.error("Gemini AI enhancement error:", error);
    
    // Fallback: return original text with basic cleanup
    const fallbackText = rawTranscription
      .replace(/\b(htn|HTN)\b/gi, "hypertension")
      .replace(/\b(t2dm|T2DM)\b/gi, "Type 2 diabetes mellitus")
      .replace(/\b(dm|DM)\b/gi, "diabetes mellitus")
      .replace(/\b(po|PO)\b/gi, "by mouth")
      .replace(/\b(bid|BID)\b/gi, "twice daily")
      .replace(/\b(tid|TID)\b/gi, "three times daily")
      .replace(/\b(qid|QID)\b/gi, "four times daily")
      .replace(/\b(qd|QD|daily)\b/gi, "once daily")
      .replace(/\b(prn|PRN)\b/gi, "as needed");
    
    return fallbackText;
  }
}

export async function extractStructuredPrescriptionData(transcription: string): Promise<EnhancedMedicalTranscription> {
  try {
    const systemPrompt = `You are a medical AI that extracts structured prescription data from transcriptions.

Extract the following information from the medical transcription and return it as JSON:

{
  "patientInfo": {
    "name": "patient name if mentioned",
    "age": "age as number if mentioned", 
    "gender": "male/female/other if mentioned",
    "phone": "phone number if mentioned"
  },
  "medicalHistory": "previous conditions, allergies, past medical history",
  "currentSymptoms": "current complaints and symptoms",
  "medications": [
    {
      "name": "medication name with strength",
      "dosage": "dosage amount",
      "frequency": "how often to take",
      "duration": "how long to take",
      "route": "oral/injection/topical/inhaled",
      "instructions": "special instructions if any"
    }
  ],
  "enhancedText": "the original transcription with medical terminology corrected",
  "originalText": "the original transcription as provided"
}

Rules:
- Only include fields that are explicitly mentioned in the transcription
- Use null for missing information
- Standardize medication names and dosages
- Convert abbreviations to full terms (HTN → Hypertension, BID → twice daily, etc.)
- Ensure medication routes are standardized (PO → Oral)
- If age is mentioned, convert to number
- Keep phone numbers in standard format`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            patientInfo: {
              type: "object",
              properties: {
                name: { type: "string" },
                age: { type: "number" },
                gender: { type: "string" },
                phone: { type: "string" }
              }
            },
            medicalHistory: { type: "string" },
            currentSymptoms: { type: "string" },
            medications: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  dosage: { type: "string" },
                  frequency: { type: "string" },
                  duration: { type: "string" },
                  route: { type: "string" },
                  instructions: { type: "string" }
                },
                required: ["name", "dosage", "frequency", "duration", "route"]
              }
            },
            enhancedText: { type: "string" },
            originalText: { type: "string" }
          },
          required: ["enhancedText", "originalText", "medications"]
        },
        temperature: 0.2
      },
      contents: [transcription],
    });

    const rawJson = response.text;

    if (!rawJson) {
      throw new Error("Empty response from Gemini AI");
    }

    console.log(`Structured extraction response: ${rawJson.substring(0, 200)}...`);

    const data: EnhancedMedicalTranscription = JSON.parse(rawJson);
    
    // Validate required fields
    if (!data.enhancedText || !data.originalText) {
      throw new Error("Missing required fields in AI response");
    }

    return data;

  } catch (error) {
    console.error("Structured extraction error:", error);
    
    // Fallback: return basic structure with enhanced text
    const enhancedText = await enhanceMedicalTranscription(transcription);
    
    return {
      patientInfo: {},
      medications: [],
      enhancedText,
      originalText: transcription
    };
  }
}

export async function validateMedicationName(medicationName: string): Promise<{ isValid: boolean; suggestions: string[]; corrected?: string }> {
  try {
    const systemPrompt = `You are a pharmaceutical expert AI. Validate and suggest corrections for medication names.

Given a medication name, determine if it's a valid medication and provide suggestions if it's misspelled or unclear.

Return JSON in this format:
{
  "isValid": true/false,
  "suggestions": ["list of similar valid medication names"],
  "corrected": "corrected name if there's an obvious correction"
}

Consider common medications, generic names, brand names, and typical dosage strengths.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            isValid: { type: "boolean" },
            suggestions: { 
              type: "array", 
              items: { type: "string" } 
            },
            corrected: { type: "string" }
          },
          required: ["isValid", "suggestions"]
        }
      },
      contents: [`Validate this medication name: "${medicationName}"`],
    });

    const rawJson = response.text;
    
    if (rawJson) {
      const result = JSON.parse(rawJson);
      return result;
    } else {
      throw new Error("Empty response from medication validation");
    }

  } catch (error) {
    console.error("Medication validation error:", error);
    
    // Fallback: assume valid but provide no suggestions
    return {
      isValid: true,
      suggestions: [],
    };
  }
}
