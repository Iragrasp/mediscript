import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const clinics = pgTable("clinics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  specialization: text("specialization"),
  address: text("address"),
  cityState: text("city_state"),
  contact: text("contact"),
  logoUrl: text("logo_url"),
  doctorName: text("doctor_name"),
  doctorLicense: text("doctor_license"),
});

export const patients = pgTable("patients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  age: integer("age"),
  gender: text("gender"),
  phone: text("phone"),
  medicalHistory: text("medical_history"),
  currentSymptoms: text("current_symptoms"),
});

export const medications = pgTable("medications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  duration: text("duration").notNull(),
  route: text("route").notNull(),
  instructions: text("instructions"),
});

export const prescriptions = pgTable("prescriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: varchar("patient_id").notNull(),
  clinicId: varchar("clinic_id").notNull(),
  medications: jsonb("medications").$type<string[]>().notNull(),
  date: timestamp("date").notNull().default(sql`now()`),
  transcription: text("transcription"),
  enhancedTranscription: text("enhanced_transcription"),
});

export const insertClinicSchema = createInsertSchema(clinics).omit({
  id: true,
});

export const insertPatientSchema = createInsertSchema(patients).omit({
  id: true,
});

export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
});

export const insertPrescriptionSchema = createInsertSchema(prescriptions).omit({
  id: true,
  date: true,
});

export type InsertClinic = z.infer<typeof insertClinicSchema>;
export type InsertPatient = z.infer<typeof insertPatientSchema>;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;

export type Clinic = typeof clinics.$inferSelect;
export type Patient = typeof patients.$inferSelect;
export type Medication = typeof medications.$inferSelect;
export type Prescription = typeof prescriptions.$inferSelect;
